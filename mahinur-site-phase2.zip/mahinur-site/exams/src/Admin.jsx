import React,{useEffect,useMemo,useState,useCallback} from 'react'
import Papa from 'papaparse'
import {sb,rpc,msg} from './supabase'
import M from './Math'
import AIGen from './AIGen'

const SUBJECTS=['Physics','Chemistry','Biology','Math','English','GK','ICT','Other']
const L='ABCD'
const dl=(name,rows)=>{const b=new Blob(['﻿'+Papa.unparse(rows)],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click()}
const toLocal=d=>{if(!d)return '';const x=new Date(d);x.setMinutes(x.getMinutes()-x.getTimezoneOffset());return x.toISOString().slice(0,16)}
const fromLocal=v=>v?new Date(v).toISOString():null
const mmss=s=>s==null?'':Math.floor(s/60)+':'+String(s%60).padStart(2,'0')

export default function Admin({tab}){
  const tabs=[['home','Dashboard'],['ai','AI generator'],['questions','Question bank'],['exams','Exams'],['results','Results'],['students','Students']]
  return <>
    <nav className="n" style={{marginBottom:20}}>{tabs.map(([k,v])=><a key={k} href={'#/admin/'+(k==='home'?'':k)} className={tab===k?'on':''}>{v}</a>)}</nav>
    {tab==='ai'?<AIGen QForm={QForm}/>:tab==='questions'?<Questions/>:tab==='exams'?<Exams/>:tab==='results'?<Results/>:tab==='students'?<Students/>:<Home/>}
  </>
}
function useLoad(fn,deps=[]){
  const [d,setD]=useState(null),[e,setE]=useState('')
  const load=useCallback(()=>{fn().then(setD).catch(x=>setE(msg(x)))},deps) // eslint-disable-line
  useEffect(()=>{load()},[load]);return [d,e,load,setD]
}

function Home(){
  const [s,e]=useLoad(async()=>{
    const c=t=>sb.from(t).select('*',{count:'exact',head:true}).then(r=>r.count)
    const [q,x,p,a]=await Promise.all([c('questions'),c('exams'),c('profiles'),c('attempts')])
    return {q,x,p,a}})
  if(e)return <p className="err">{e}</p>
  const cards=s?[['Questions',s.q],['Exams',s.x],['Registered users',s.p],['Attempts',s.a]]:[]
  return <><h1>Dashboard</h1>
    <div className="grid" style={{margin:'18px 0'}}>{s?cards.map(([k,v])=><div className="card" key={k}><div className="stat">{v}</div><div className="mu">{k}</div></div>):<div className="skel"/>}</div>
    <div className="row"><a className="btn" href="#/admin/ai">AI question generator</a><a className="btn line" href="#/admin/questions">Add questions</a><a className="btn line" href="#/admin/exams">Create an exam</a></div>
    <p className="mu sm" style={{marginTop:24}}>Scores and charts (average, distribution, hardest questions) arrive in Phase 3.</p></>
}

/* ------------------------------ Question bank ------------------------------ */
const blankQ={subject:'Physics',topic:'',difficulty:'medium',text:'',options:['','','',''],correct_index:0,explanation:'',source:'',image_url:''}
function Questions(){
  const [rows,err,load]=useLoad(async()=>{
    const [q,u]=await Promise.all([sb.from('questions').select('*').eq('status','approved').order('created_at',{ascending:false}),sb.from('exam_questions').select('question_id')])
    if(q.error)throw q.error
    const use={};(u.data||[]).forEach(r=>use[r.question_id]=(use[r.question_id]||0)+1)
    return q.data.map(r=>({...r,uses:use[r.id]||0}))})
  const [f,setF]=useState({s:'',sub:'',dif:''}),[ed,setEd]=useState(null),[note,setNote]=useState('')
  const shown=useMemo(()=>(rows||[]).filter(r=>(!f.sub||r.subject===f.sub)&&(!f.dif||r.difficulty===f.dif)&&(!f.s||(r.text+r.topic+r.source).toLowerCase().includes(f.s.toLowerCase()))),[rows,f])
  const del=async q=>{if(!confirm('Delete this question?'))return;const {error}=await sb.from('questions').delete().eq('id',q.id);error?setNote(/violates foreign key/.test(error.message)?'This question is used in an exam. Remove it from the exam first.':error.message):(setNote(''),load())}
  const importCsv=file=>{
    Papa.parse(file,{header:true,skipEmptyLines:true,complete:async r=>{
      const out=[],bad=[]
      r.data.forEach((x,i)=>{
        const g=k=>(x[k]||'').toString().trim(),ci='ABCD'.indexOf(g('correct').toUpperCase()),dif=(g('difficulty')||'medium').toLowerCase()
        const o=[g('option_a'),g('option_b'),g('option_c'),g('option_d')]
        if(!g('question')||!g('subject')||o.some(v=>!v)||ci<0||!['easy','medium','hard'].includes(dif))bad.push(i+2)
        else out.push({subject:g('subject'),topic:g('topic'),difficulty:dif,text:g('question'),options:o,correct_index:ci,explanation:g('explanation'),source:g('source')})})
      if(bad.length){setNote('Nothing imported. Please fix these CSV rows (row 1 is the header): '+bad.slice(0,20).join(', '));return}
      if(!out.length){setNote('The file has no questions.');return}
      const {error}=await sb.from('questions').insert(out)
      error?setNote(error.message):(setNote('Imported '+out.length+' questions.'),load())}})}
  return <>
    <div className="row sp"><h1>Question bank</h1><div className="row">
      <button className="btn" onClick={()=>setEd({...blankQ})}>Add question</button>
      <label className="btn line" style={{cursor:'pointer'}}>Import CSV<input type="file" accept=".csv" hidden onChange={e=>{e.target.files[0]&&importCsv(e.target.files[0]);e.target.value=''}}/></label>
      <button className="btn line" onClick={()=>dl('questions.csv',(rows||[]).map(r=>({subject:r.subject,topic:r.topic,difficulty:r.difficulty,question:r.text,option_a:r.options[0],option_b:r.options[1],option_c:r.options[2],option_d:r.options[3],correct:L[r.correct_index],explanation:r.explanation,source:r.source})))}>Export CSV</button>
      <button className="btn line" onClick={()=>dl('questions-template.csv',[{subject:'Physics',topic:'Motion',difficulty:'easy',question:'Unit of force is?',option_a:'Newton',option_b:'Joule',option_c:'Watt',option_d:'Pascal',correct:'A',explanation:'F = ma, measured in newtons ($N$).',source:'Book p.12'}])}>CSV template</button></div></div>
    <div className="three" style={{margin:'14px 0'}}>
      <input type="text" placeholder="Search text, topic or source" value={f.s} onChange={e=>setF({...f,s:e.target.value})}/>
      <select value={f.sub} onChange={e=>setF({...f,sub:e.target.value})}><option value="">All subjects</option>{[...new Set([...SUBJECTS,...(rows||[]).map(r=>r.subject)])].map(s=><option key={s}>{s}</option>)}</select>
      <select value={f.dif} onChange={e=>setF({...f,dif:e.target.value})}><option value="">All difficulties</option><option>easy</option><option>medium</option><option>hard</option></select></div>
    {note&&<p className={/Imported/.test(note)?'ok':'err'}>{note}</p>}
    {err&&<p className="err">{err}</p>}
    {!rows?<div className="skel"/>:!shown.length?<div className="empty card"><h3>No questions</h3><p>Add one, or import a CSV.</p></div>
    :shown.map(q=><div className="card" key={q.id} style={{marginBottom:10}}>
      <div className="row sp"><div className="row"><span className="chip gold">{q.subject}</span>{q.topic&&<span className="chip">{q.topic}</span>}<span className="chip">{q.difficulty}</span><span className="chip">used in {q.uses} exam{q.uses===1?'':'s'}</span></div>
        <div className="row"><button className="btn s line" onClick={()=>setEd({...q,image_url:q.image_url||''})}>Edit</button><button className="btn s bad" onClick={()=>del(q)}>Delete</button></div></div>
      <p style={{margin:'10px 0 6px',whiteSpace:'pre-wrap'}}><M t={q.text}/></p>
      <p className="sm mu" style={{margin:0}}>{q.options.map((o,i)=><span key={i} style={{marginRight:14,color:i===q.correct_index?'var(--ok)':undefined}}>{L[i]}) <M t={o}/></span>)}</p></div>)}
    {ed&&<QForm q={ed} close={()=>setEd(null)} saved={()=>{setEd(null);load()}}/>}
  </>
}
function QForm({q,close,saved}){
  const [v,setV]=useState(q),[er,setEr]=useState(''),[bz,setBz]=useState(false),[up,setUp]=useState(false)
  const set=(k,x)=>setV(p=>({...p,[k]:x}))
  const upload=async f=>{setUp(true);setEr('');const path=Date.now()+'-'+f.name.replace(/[^\w.-]/g,'_');const {error}=await sb.storage.from('question-images').upload(path,f);if(error)setEr(error.message);else set('image_url',sb.storage.from('question-images').getPublicUrl(path).data.publicUrl);setUp(false)}
  const save=async()=>{
    if(!v.text.trim()||v.options.some(o=>!o.trim())||!v.subject.trim())return setEr('Fill in the subject, the question and all four options.')
    setBz(true);setEr('')
    const row={subject:v.subject.trim(),topic:v.topic.trim(),difficulty:v.difficulty,text:v.text.trim(),options:v.options.map(o=>o.trim()),correct_index:+v.correct_index,explanation:v.explanation.trim(),source:v.source.trim(),image_url:v.image_url||null}
    const {error}=v.id?await sb.from('questions').update(row).eq('id',v.id):await sb.from('questions').insert(row)
    error?(setEr(error.message),setBz(false)):saved()}
  return <div className="modal"><div className="card">
    <h2 style={{marginTop:0}}>{v.id?'Edit question':'New question'}</h2>
    <div className="three"><label className="f">Subject (pick, or type a new one)<input type="text" list="subs" value={v.subject} onChange={e=>set('subject',e.target.value)}/><datalist id="subs">{SUBJECTS.map(s=><option key={s}>{s}</option>)}</datalist></label>
      <label className="f">Topic<input type="text" value={v.topic} onChange={e=>set('topic',e.target.value)}/></label>
      <label className="f">Difficulty<select value={v.difficulty} onChange={e=>set('difficulty',e.target.value)}><option>easy</option><option>medium</option><option>hard</option></select></label></div>
    <label className="f">Question (formulas: $x^2$ or $\ce{'{H2O}'}$)<textarea value={v.text} onChange={e=>set('text',e.target.value)}/></label>
    {v.text&&<p className="sm mu">Preview: <M t={v.text}/></p>}
    {v.options.map((o,i)=><div className="row" key={i} style={{marginBottom:8,flexWrap:'nowrap'}}>
      <input type="radio" name="cor" checked={+v.correct_index===i} onChange={()=>set('correct_index',i)} aria-label={'Option '+L[i]+' is correct'} style={{width:22,height:22,flex:'none'}}/>
      <input type="text" placeholder={'Option '+L[i]} value={o} onChange={e=>set('options',v.options.map((x,j)=>j===i?e.target.value:x))} style={{margin:0}}/></div>)}
    <p className="sm mu">Tick the circle next to the correct option.</p>
    <label className="f">Explanation shown after the exam<textarea value={v.explanation} onChange={e=>set('explanation',e.target.value)}/></label>
    <div className="two"><label className="f">Source (book, page)<input type="text" value={v.source} onChange={e=>set('source',e.target.value)}/></label>
      <label className="f">Image (optional){v.image_url&&<img src={v.image_url} alt="" style={{maxHeight:60,display:'block',margin:'4px 0'}}/>}<input type="file" accept="image/*" onChange={e=>e.target.files[0]&&upload(e.target.files[0])}/>{up&&<span className="sm">Uploading…</span>}</label></div>
    {er&&<p className="err">{er}</p>}
    <div className="row"><button className="btn" disabled={bz||up} onClick={save}>{bz?'Saving…':'Save'}</button><button className="btn line" onClick={close}>Cancel</button></div>
  </div></div>
}

/* ------------------------------ Exams ------------------------------ */
const blankE={title:'',subject:'Physics',topic:'',kind:'practice',marks_per_q:1,negative:0,duration_min:30,starts_at:'',ends_at:'',max_attempts:1,shuffle:false,results_mode:'instant',published:false}
function Exams(){
  const [rows,err,load]=useLoad(async()=>{
    const [e,c]=await Promise.all([sb.from('exams').select('*').order('created_at',{ascending:false}),sb.from('exam_questions').select('exam_id')])
    if(e.error)throw e.error
    const n={};(c.data||[]).forEach(r=>n[r.exam_id]=(n[r.exam_id]||0)+1)
    return e.data.map(x=>({...x,n:n[x.id]||0}))})
  const [ed,setEd]=useState(()=>{try{const q=JSON.parse(sessionStorage.getItem('prefillQids')||'null');sessionStorage.removeItem('prefillQids');if(q&&q.length)return {...blankE,title:'',qids:q}}catch{}return null}),[pv,setPv]=useState(null),[note,setNote]=useState('')
  const toggle=async e=>{const {error}=await sb.from('exams').update({published:!e.published}).eq('id',e.id);error?setNote(error.message):load()}
  const del=async e=>{if(!confirm('Delete "'+e.title+'" and all student attempts on it?'))return;const {error}=await sb.from('exams').delete().eq('id',e.id);error?setNote(error.message):load()}
  const dup=async e=>{
    const {n,id,created_at,...rest}=e
    const {data,error}=await sb.from('exams').insert({...rest,title:e.title+' (copy)',published:false}).select().single()
    if(error)return setNote(error.message)
    const {data:qs}=await sb.from('exam_questions').select('question_id,position').eq('exam_id',id)
    if(qs&&qs.length)await sb.from('exam_questions').insert(qs.map(q=>({...q,exam_id:data.id})))
    load()}
  const open=async e=>{const {data}=await sb.from('exam_questions').select('question_id').eq('exam_id',e.id).order('position');setEd({...e,starts_at:toLocal(e.starts_at),ends_at:toLocal(e.ends_at),qids:(data||[]).map(x=>x.question_id)})}
  const preview=async e=>{const {data}=await sb.from('exam_questions').select('position,questions(*)').eq('exam_id',e.id).order('position');setPv({e,qs:(data||[]).map(x=>x.questions)})}
  return <>
    <div className="row sp"><h1>Exams</h1><button className="btn" onClick={()=>setEd({...blankE,qids:[]})}>Create exam</button></div>
    {note&&<p className="err">{note}</p>}{err&&<p className="err">{err}</p>}
    {!rows?<div className="skel" style={{marginTop:14}}/>:!rows.length?<div className="empty card" style={{marginTop:14}}><h3>No exams yet</h3><p>Add some questions first, then create your first exam.</p></div>
    :rows.map(e=><div className="card" key={e.id} style={{marginTop:12}}>
      <div className="row sp"><div><h3><M t={e.title}/></h3><p className="mu sm" style={{margin:0}}>{e.subject}{e.topic?' · '+e.topic:''} · {e.kind} · {e.n} questions · {e.duration_min} min{e.starts_at?' · '+new Date(e.starts_at).toLocaleString():''}</p></div>
        <span className={'chip '+(e.published?'live':'')}>{e.published?'Published':'Draft'}</span></div>
      <div className="row" style={{marginTop:12}}>
        <button className="btn s" onClick={()=>toggle(e)}>{e.published?'Unpublish':'Publish'}</button>
        <button className="btn s line" onClick={()=>open(e)}>Edit</button>
        <button className="btn s line" onClick={()=>preview(e)}>Preview</button>
        <button className="btn s line" onClick={()=>dup(e)}>Duplicate</button>
        <button className="btn s bad" onClick={()=>del(e)}>Delete</button></div></div>)}
    {ed&&<EForm e={ed} close={()=>setEd(null)} saved={()=>{setEd(null);load()}}/>}
    {pv&&<div className="modal" onClick={()=>setPv(null)}><div className="card" onClick={e=>e.stopPropagation()}>
      <h2 style={{marginTop:0}}>Preview: {pv.e.title}</h2><p className="mu sm">This is how students see the questions. Answers stay hidden.</p>
      {pv.qs.map((q,i)=><div key={q.id} style={{marginBottom:16}}><div className="qtext"><b>{i+1}.</b> <M t={q.text}/></div>{q.options.map((o,j)=><div key={j} className="opt" style={{cursor:'default'}}><span className="bub">{L[j]}</span><span><M t={o}/></span></div>)}</div>)}
      <button className="btn line" onClick={()=>setPv(null)}>Close</button></div></div>}
  </>
}
function EForm({e,close,saved}){
  const [v,setV]=useState(e),[er,setEr]=useState(''),[bz,setBz]=useState(false)
  const [bank]=useLoad(async()=>{const {data,error}=await sb.from('questions').select('id,subject,topic,difficulty,text').eq('status','approved').order('subject').order('topic');if(error)throw error;return data})
  const [f,setF]=useState({s:'',sub:''})
  const set=(k,x)=>setV(p=>({...p,[k]:x}))
  const sel=new Set(v.qids)
  const flip=id=>set('qids',sel.has(id)?v.qids.filter(x=>x!==id):[...v.qids,id])
  const shown=(bank||[]).filter(q=>(!f.sub||q.subject===f.sub)&&(!f.s||(q.text+q.topic).toLowerCase().includes(f.s.toLowerCase())))
  const save=async()=>{
    if(!v.title.trim())return setEr('Give the exam a name.')
    if(!v.qids.length)return setEr('Tick at least one question.')
    if(v.kind==='live'&&(!v.starts_at||!v.ends_at))return setEr('A live exam needs a start and an end time.')
    if(v.starts_at&&v.ends_at&&new Date(v.ends_at)<=new Date(v.starts_at))return setEr('The end time must be after the start time.')
    setBz(true);setEr('')
    const row={title:v.title.trim(),subject:v.subject.trim()||'Other',topic:v.topic.trim(),kind:v.kind,marks_per_q:+v.marks_per_q,negative:+v.negative,duration_min:+v.duration_min,starts_at:fromLocal(v.starts_at),ends_at:fromLocal(v.ends_at),max_attempts:+v.max_attempts,shuffle:v.shuffle,results_mode:v.results_mode,published:v.published}
    let id=v.id,error
    if(id)({error}=await sb.from('exams').update(row).eq('id',id))
    else{const r=await sb.from('exams').insert(row).select().single();error=r.error;id=r.data&&r.data.id}
    if(!error){
      const d=await sb.from('exam_questions').delete().eq('exam_id',id);error=d.error
      if(!error){const i=await sb.from('exam_questions').insert(v.qids.map((q,p)=>({exam_id:id,question_id:q,position:p})));error=i.error}}
    error?(setEr(error.message),setBz(false)):saved()}
  return <div className="modal"><div className="card" style={{maxWidth:900}}>
    <h2 style={{marginTop:0}}>{v.id?'Edit exam':'New exam'}</h2>
    <label className="f">Exam name<input type="text" value={v.title} onChange={e=>set('title',e.target.value)}/></label>
    <div className="three"><label className="f">Subject (pick, or type a new one)<input type="text" list="subs2" value={v.subject} onChange={e=>set('subject',e.target.value)}/><datalist id="subs2">{SUBJECTS.map(s=><option key={s}>{s}</option>)}</datalist></label>
      <label className="f">Topic<input type="text" value={v.topic} onChange={e=>set('topic',e.target.value)}/></label>
      <label className="f">Type<select value={v.kind} onChange={e=>set('kind',e.target.value)}><option value="practice">Practice (anytime)</option><option value="live">Live (fixed window)</option></select></label></div>
    <div className="three"><label className="f">Marks per question<input type="number" min="0.25" step="0.25" value={v.marks_per_q} onChange={e=>set('marks_per_q',e.target.value)}/></label>
      <label className="f">Negative marks per wrong (0 = off)<input type="number" min="0" step="0.25" value={v.negative} onChange={e=>set('negative',e.target.value)}/></label>
      <label className="f">Duration (minutes)<input type="number" min="1" value={v.duration_min} onChange={e=>set('duration_min',e.target.value)}/></label></div>
    <div className="three"><label className="f">{v.kind==='live'?'Starts':'Opens (optional)'}<input type="datetime-local" value={v.starts_at} onChange={e=>set('starts_at',e.target.value)}/></label>
      <label className="f">{v.kind==='live'?'Ends':'Closes (optional)'}<input type="datetime-local" value={v.ends_at} onChange={e=>set('ends_at',e.target.value)}/></label>
      <label className="f">Attempts allowed (0 = unlimited)<input type="number" min="0" value={v.max_attempts} onChange={e=>set('max_attempts',e.target.value)}/></label></div>
    <div className="two"><label className="f">Show results<select value={v.results_mode} onChange={e=>set('results_mode',e.target.value)}><option value="instant">Right after submit</option><option value="after_end">After the exam window ends</option></select></label>
      <label className="f" style={{display:'flex',gap:10,alignItems:'center',marginTop:22}}><input type="checkbox" checked={v.shuffle} onChange={e=>set('shuffle',e.target.checked)} style={{width:22,height:22}}/>Shuffle questions and options</label></div>
    <label className="f" style={{display:'flex',gap:10,alignItems:'center'}}><input type="checkbox" checked={v.published} onChange={e=>set('published',e.target.checked)} style={{width:22,height:22}}/>Published (visible to students)</label>
    <h3 style={{margin:'14px 0 8px'}}>Questions ({v.qids.length} selected)</h3>
    <div className="two"><input type="text" placeholder="Search" value={f.s} onChange={e=>setF({...f,s:e.target.value})}/><select value={f.sub} onChange={e=>setF({...f,sub:e.target.value})}><option value="">All subjects</option>{[...new Set((bank||[]).map(q=>q.subject))].map(s=><option key={s}>{s}</option>)}</select></div>
    <div style={{maxHeight:280,overflow:'auto',margin:'10px 0',border:'1px solid var(--line)',borderRadius:12}}>
      {!bank?<div className="skel"/>:!shown.length?<p className="empty">No questions found. Add some in the Question bank.</p>
      :shown.map(q=><label key={q.id} style={{display:'flex',gap:10,padding:'10px 12px',borderBottom:'1px solid var(--line)',cursor:'pointer'}}><input type="checkbox" checked={sel.has(q.id)} onChange={()=>flip(q.id)} style={{width:20,height:20,flex:'none'}}/><span className="sm"><span className="mu">{q.subject}{q.topic?' · '+q.topic:''} · {q.difficulty}</span><br/><M t={q.text}/></span></label>)}</div>
    {er&&<p className="err">{er}</p>}
    <div className="row"><button className="btn" disabled={bz} onClick={save}>{bz?'Saving…':'Save exam'}</button><button className="btn line" onClick={close}>Cancel</button></div>
  </div></div>
}

/* ------------------------------ Results & students ------------------------------ */
function Results(){
  const [rows,err]=useLoad(()=>rpc('admin_results'))
  const [ex,setEx]=useState('')
  if(err)return <p className="err">{err}</p>
  if(!rows)return <div className="skel"/>
  const exams=[...new Set(rows.map(r=>r.exam))],shown=rows.filter(r=>!ex||r.exam===ex)
  return <><div className="row sp"><h1>Results</h1><button className="btn line" onClick={()=>dl('results.csv',shown.map(r=>({exam:r.exam,student:r.student,score:r.score,correct:r.correct,wrong:r.wrong,skipped:r.skipped,time:mmss(r.secs),submitted:r.submitted_at})))}>Export CSV</button></div>
    <select value={ex} onChange={e=>setEx(e.target.value)} style={{maxWidth:320,margin:'12px 0'}}><option value="">All exams</option>{exams.map(x=><option key={x}>{x}</option>)}</select>
    {!shown.length?<div className="empty card"><h3>No results yet</h3></div>:<div className="card tw"><table><thead><tr><th>Student</th><th>Exam</th><th>Score</th><th>✓ / ✗ / –</th><th>Time</th><th>Submitted</th></tr></thead><tbody>
      {shown.map(r=><tr key={r.attempt_id}><td>{r.student}</td><td>{r.exam}</td><td><b>{r.score}</b></td><td>{r.correct} / {r.wrong} / {r.skipped}</td><td>{mmss(r.secs)}</td><td>{new Date(r.submitted_at).toLocaleString()}</td></tr>)}</tbody></table></div>}</>
}
function Students(){
  const [rows,err,load]=useLoad(()=>rpc('admin_students')),[note,setNote]=useState('')
  const blk=async s=>{try{await rpc('set_blocked',{p_uid:s.id,p_blocked:!s.blocked});load()}catch(e){setNote(msg(e))}}
  if(err)return <p className="err">{err}</p>
  if(!rows)return <div className="skel"/>
  return <><div className="row sp"><h1>Students</h1><button className="btn line" onClick={()=>dl('students.csv',rows.map(r=>({name:r.name,email:r.email,joined:r.joined,attempts:r.attempts,blocked:r.blocked})))}>Export CSV</button></div>
    {note&&<p className="err">{note}</p>}
    <div className="card tw" style={{marginTop:14}}><table><thead><tr><th>Name</th><th>Email</th><th>Joined</th><th>Exams taken</th><th></th></tr></thead><tbody>
      {rows.map(s=><tr key={s.id}><td>{s.name} {s.role==='admin'&&<span className="chip gold">teacher</span>}{s.blocked&&<span className="chip">blocked</span>}</td><td>{s.email}</td><td>{new Date(s.joined).toLocaleDateString()}</td><td>{s.attempts}</td>
        <td>{s.role!=='admin'&&<button className={'btn s '+(s.blocked?'line':'bad')} onClick={()=>blk(s)}>{s.blocked?'Unblock':'Block'}</button>}</td></tr>)}</tbody></table></div></>
}
