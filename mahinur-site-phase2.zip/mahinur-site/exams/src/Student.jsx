import React,{useEffect,useState,useCallback} from 'react'
import {rpc,msg,sb} from './supabase'
import {go} from './App'
import M from './Math'

const fmtDT=d=>d?new Date(d).toLocaleString([], {day:'numeric',month:'short',hour:'numeric',minute:'2-digit'}):''
const mmss=s=>{s=Math.max(0,s);const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return (h?h+':'+String(m).padStart(2,'0'):m)+':'+String(s%60).padStart(2,'0')}
function useExams(){
  const [list,setList]=useState(null),[err,setErr]=useState(''),[off,setOff]=useState(0)
  const load=useCallback(()=>rpc('student_exams').then(r=>{const sn=r.find(x=>x.server_now);setOff(sn?new Date(sn.server_now)-Date.now():0);setList(r.filter(x=>x.id))}).catch(e=>setErr(msg(e))),[])
  useEffect(()=>{load()},[load])
  return {list,err,off,load}
}
export function status(e,now){
  if(e.kind==='practice')return e.attempts>0&&!e.open_attempt?'attempted':'practice'
  const s=e.starts_at&&new Date(e.starts_at).getTime(),n=e.ends_at&&new Date(e.ends_at).getTime()
  if(e.open_attempt)return 'live'
  if(e.attempts>0)return 'attempted'
  if(s&&now<s)return 'upcoming'
  if(n&&now>=n)return 'completed'
  return 'live'
}
const CH={live:['live','Live'],upcoming:['up','Upcoming'],completed:['done','Completed'],attempted:['gold','Attempted'],practice:['gold','Practice']}
function Card({e,now}){
  const st=status(e,now),[c,l]=CH[st]
  return <a href={'#/exam/'+e.id} className="card" style={{display:'block',color:'inherit'}}>
    <div className="row sp"><span className={'chip '+c}>{l}</span><span className="chip">{e.kind==='live'?'Live exam':'Practice'}</span></div>
    <h3 style={{margin:'12px 0 4px'}}><M t={e.title}/></h3>
    <p className="mu sm">{e.topic||e.subject}</p>
    <p className="sm" style={{margin:0}}>{e.question_count} questions · {e.question_count*e.marks_per_q} marks · {e.duration_min} min<br/>
    {e.negative>0?'Negative marking −'+e.negative:'No negative marking'}{e.starts_at?<><br/>{fmtDT(e.starts_at)}</>:null}</p>
  </a>
}
function Dashboard(){
  const {list,err,off}=useExams(),[now,setNow]=useState(Date.now())
  useEffect(()=>{const t=setInterval(()=>setNow(Date.now()),30000);return()=>clearInterval(t)},[])
  const [sub,setSub]=useState('All')
  if(err)return <p className="err">{err}</p>
  if(!list)return <div className="grid"><div className="skel"/><div className="skel"/><div className="skel"/></div>
  const n=now+off,subs=['All',...new Set(list.map(e=>e.subject))]
  const shown=list.filter(e=>sub==='All'||e.subject===sub)
  return <>
    <h1>Exams</h1><p className="mu">Pick a subject, then an exam.</p>
    <div className="row" style={{margin:'14px 0 20px'}}>{subs.map(s=><button key={s} className={'btn s '+(s===sub?'':'line')} onClick={()=>setSub(s)}>{s}</button>)}</div>
    {!shown.length?<div className="empty card"><h3>No exams yet</h3><p>The teacher has not published an exam here. Please check back soon.</p></div>
    :<div className="grid">{shown.map(e=><Card key={e.id} e={e} now={n}/>)}</div>}
  </>
}
function Pre({id}){
  const {list,err,off,load}=useExams(),[now,setNow]=useState(Date.now()),[bz,setBz]=useState(false),[er,setEr]=useState('')
  useEffect(()=>{const t=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(t)},[])
  if(err)return <p className="err">{err}</p>
  if(!list)return <div className="skel"/>
  const e=list.find(x=>x.id===id)
  if(!e)return <div className="empty card"><h3>Exam not found</h3><a href="#/">Back to exams</a></div>
  const n=now+off,st=status(e,n),start=e.starts_at&&new Date(e.starts_at).getTime()
  const left=e.attempts>=e.max_attempts&&e.max_attempts>0&&!e.open_attempt
  const can=!left&&(e.open_attempt||st==='live'||st==='practice')
  const begin=async()=>{setBz(true);setEr('');try{const a=await rpc('start_attempt',{p_exam:id});try{await document.documentElement.requestFullscreen?.()}catch{};go('attempt/'+a)}catch(x){setEr(msg(x));setBz(false);load()}}
  return <>
    <a href="#/" className="mu sm">&larr; All exams</a>
    <h1 style={{margin:'10px 0 6px'}}><M t={e.title}/></h1>
    <p className="mu">{e.subject}{e.topic?' · '+e.topic:''}</p>
    <div className="card" style={{margin:'18px 0'}}>
      <h3>Marking scheme</h3>
      <p style={{margin:'8px 0 0'}}>{e.question_count} questions · {e.marks_per_q} mark per correct answer<br/>
      {e.negative>0?<>−{e.negative} for each wrong answer. Unanswered questions score 0.</>:'No negative marking.'}<br/>
      Duration: {e.duration_min} minutes · Attempts allowed: {e.max_attempts===0?'unlimited':e.max_attempts}</p>
      <h3 style={{marginTop:18}}>Rules</h3>
      <ul className="mu" style={{margin:'8px 0 0',paddingLeft:20}}>
        <li>The timer runs on the server. Closing the page does not pause it.</li>
        <li>Your answers are saved as you tap. If your internet drops, keep going; they sync when it returns.</li>
        <li>When time ends, your exam is submitted automatically.</li>
        <li>{e.results_mode==='instant'?'Results are shown right after you submit.':'Results are shown after the exam window ends.'}</li>
      </ul>
    </div>
    {st==='upcoming'&&start&&<div className="card" style={{textAlign:'center'}}><p className="mu">Starts in</p><div className="timer">{mmss(Math.floor((start-n)/1000))}</div><p className="mu sm">{fmtDT(e.starts_at)}</p></div>}
    <div className="row" style={{marginTop:16}}>
      <button className="btn" disabled={!can||bz} onClick={begin}>{e.open_attempt?'Resume exam':st==='upcoming'?'Not started yet':st==='completed'?'Exam ended':left?'No attempts left':'Start exam'}</button>
      {e.last_attempt&&<a className="btn line" href={'#/result/'+e.last_attempt}>View my result</a>}
    </div>
    {er&&<p className="err" style={{marginTop:12}}>{er}</p>}
  </>
}
function Result({id}){
  const [r,setR]=useState(null),[err,setErr]=useState('')
  useEffect(()=>{rpc('get_result',{p_attempt:id}).then(setR).catch(e=>setErr(msg(e)))},[id])
  if(err)return <><p className="err">{err}</p><a href="#/">Back to exams</a></>
  if(!r)return <div className="skel"/>
  if(!r.released)return <><h1>{r.title}</h1><div className="card empty" style={{marginTop:16}}><h3>Submitted</h3><p>Your answers are safely recorded. Results will be shown after {fmtDT(r.releases_at)}.</p><a className="btn" href="#/">Back to exams</a></div></>
  const att=r.correct+r.wrong,acc=att?Math.round(r.correct/att*100):0,L='ABCD'
  return <>
    <a href="#/" className="mu sm">&larr; All exams</a>
    <h1 style={{margin:'10px 0'}}><M t={r.title}/></h1>
    <div className="score"><big>{r.score} / {r.total_marks}</big>
      <span className="mu">{r.correct} correct · {r.wrong} wrong · {r.skipped} skipped · accuracy {acc}% · {mmss(r.secs)}</span></div>
    <h2>Review</h2>
    {r.review.map((q,i)=><div className="card" key={q.id} style={{marginBottom:12}}>
      <div className="qtext"><b>{i+1}.</b> <M t={q.text}/></div>
      {q.image_url&&<img src={q.image_url} alt="" style={{maxWidth:'100%',borderRadius:12,marginBottom:8}}/>}
      {q.options.map((o,j)=><div key={j} className={'opt rv '+(j===q.correct?'c':j===q.chosen?'w':'')} style={{cursor:'default'}}><span className="bub">{L[j]}</span><span><M t={o}/></span></div>)}
      <p className="sm mu" style={{marginTop:10}}>{q.chosen==null?'You skipped this question. ':q.chosen===q.correct?'You got this right. ':'You answered '+L[q.chosen]+'. '}Correct answer: {L[q.correct]}.</p>
      {q.explanation&&<p className="sm" style={{margin:0}}><b>Explanation:</b> <M t={q.explanation}/></p>}
    </div>)}
  </>
}
export default function Student({page,id}){
  if(page==='exam')return <Pre id={id}/>
  if(page==='result')return <Result id={id}/>
  return <Dashboard/>
}
