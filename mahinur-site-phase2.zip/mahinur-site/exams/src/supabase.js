import {createClient} from '@supabase/supabase-js'
import {SUPABASE_URL,SUPABASE_KEY} from './config'
export const configured = !SUPABASE_URL.startsWith('PASTE') && !SUPABASE_KEY.startsWith('PASTE')
export const sb = createClient(configured?SUPABASE_URL:'https://x.supabase.co', configured?SUPABASE_KEY:'x')
export async function rpc(name,args){const {data,error}=await sb.rpc(name,args||{});if(error)throw error;return data}
export const msg=e=>(e&&e.message)||String(e)
// Calls the server function that talks to Claude. Returns {made,skipped} or throws a friendly Error (with .code).
export async function aiCall(body){
  const {data,error}=await sb.functions.invoke('generate-questions',{body})
  if(error){
    let m=error.message,code
    try{const j=await error.context.json();m=j.error||m;code=j.code}catch{}
    if(/Failed to fetch|NetworkError|Failed to send/i.test(m))m='No internet, or the AI function is not deployed yet.'
    const e=new Error(m);e.code=code;throw e}
  if(data&&data.error){const e=new Error(data.error);e.code=data.code;throw e}
  return data
}
