import React,{useEffect,useRef,useState,useCallback} from 'react'
import {rpc,msg} from './supabase'
import {go} from './App'
import M from './Math'

const L='ABCD'
const mmss=s=>{s=Math.max(0,s);const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return (h?h+':'+String(m).padStart(2,'0'):String(m))+':'+String(s%60).padStart(2,'0')}
// stable shuffle of the 4 option positions, same on every reload for the same student/question
function perm(seed){
  let h=2166136261;for(const ch of seed){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}
  const r=()=>{h+=0x6D2B79F5;let t=Math.imul(h^h>>>15,1|h);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}
  const a=[0,1,2,3];for(let i=3;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a
}
export default function Take({id}){
  const [d,setD]=useState(null),[err,setErr]=useState('')
  const [ans,setAns]=useState({}),[cur,setCur]=useState(0),[left,setLeft]=useState(null)
  const [sync,setSync]=useState('saved'),[confirm,setConfirm]=useState(false),[pal,setPal]=useState(false)
  const [busy,setBusy]=useState(false),[subErr,setSubErr]=useState('')
  const lastTry=useRef(0),off=useRef(0),dl=useRef(0),pend=useRef({}),flushing=useRef(false),done=useRef(false)
  const key='pending:'+id
  const persist=()=>{try{localStorage.setItem(key,JSON.stringify(pend.current))}catch{}}

  const finish=useCallback(()=>{done.current=true;try{localStorage.removeItem(key)}catch{};document.fullscreenElement&&document.exitFullscreen?.().catch(()=>{});go('result/'+id)},[id,key])

  const flush=useCallback(async()=>{
    if(flushing.current||done.current)return
    flushing.current=true
    try{
      for(const q of Object.keys(pend.current)){
        const v=pend.current[q]
        try{await rpc('save_answer',{p_attempt:id,p_question:q,p_chosen:v.c,p_marked:!!v.m})
          if(pend.current[q]===v)delete pend.current[q]
        }catch(e){
          if(/Time is up|already submitted/i.test(msg(e))){delete pend.current[q];persist();setSync('late');return}
          throw e}
      }
      persist();setSync(Object.keys(pend.current).length?'wait':'saved')
    }catch{setSync('offline')}
    flushing.current=false
  },[id])

  useEffect(()=>{
    rpc('get_attempt',{p_attempt:id}).then(r=>{
      if(r.status==='submitted'){go('result/'+id);return}
      let p={};try{p=JSON.parse(localStorage.getItem(key)||'{}')}catch{}
      pend.current=p
      const a={};Object.entries(r.answers).forEach(([q,v])=>a[q]={c:v.c,m:v.m});Object.entries(p).forEach(([q,v])=>a[q]=v)
      off.current=new Date(r.server_now)-Date.now();dl.current=new Date(r.deadline_at).getTime()
      setAns(a);setD(r);flush()
    }).catch(e=>setErr(msg(e)))
  },[id,key,flush])

  const submit=useCallback(async()=>{
    if(busy||done.current)return
    setBusy(true);setSubErr('')
    try{await flush();await rpc('submit_attempt',{p_attempt:id});finish()}
    catch(e){setSubErr(navigator.onLine?msg(e):'No internet. Your answers are saved on this phone. Reconnect and tap Submit again.');setBusy(false)}
  },[busy,flush,id,finish])
  const subRef=useRef(submit);subRef.current=submit

  useEffect(()=>{
    if(!d)return
    const t=setInterval(()=>{
      const s=Math.round((dl.current-(Date.now()+off.current))/1000);setLeft(s)
      if(s<=0&&!done.current&&Date.now()-lastTry.current>4000){lastTry.current=Date.now();subRef.current()}
    },500)
    const f=setInterval(()=>{if(Object.keys(pend.current).length)flush()},6000)
    const on=()=>flush();addEventListener('online',on)
    return()=>{clearInterval(t);clearInterval(f);removeEventListener('online',on)}
  },[d,flush])

  if(err)return <div style={{paddingTop:40}}><p className="err">{err}</p><a href="#/">Back to exams</a></div>
  if(!d)return <div style={{paddingTop:40}}><div className="skel"/></div>

  const Q=d.questions,q=Q[cur],a=ans[q.id]||{c:null,m:false}
  const set=(patch)=>{const v={...a,...patch};setAns(x=>({...x,[q.id]:v}));pend.current[q.id]=v;persist();setSync('wait');flush()}
  const p=perm(id+q.id),order=d.exam.shuffle?p:[0,1,2,3]
  const stOf=x=>{const v=ans[x.id];return v&&v.m?'m':v&&v.c!=null?'a':''}
  const nAns=Q.filter(x=>ans[x.id]&&ans[x.id].c!=null).length,nMark=Q.filter(x=>ans[x.id]&&ans[x.id].m).length
  const palette=<>
    <div className="pal">{Q.map((x,i)=><button key={x.id} className={'pb '+stOf(x)+(i===cur?' cur':'')} onClick={()=>{setCur(i);setPal(false)}} aria-label={'Question '+(i+1)}>{i+1}</button>)}</div>
    <div className="legend"><span><i style={{background:'var(--ok)'}}/>Answered</span><span><i style={{background:'var(--mark)'}}/>Marked</span><span><i style={{background:'var(--line)'}}/>Not answered</span></div>
  </>
  const syncTxt={saved:'All answers saved',wait:'Saving…',offline:'Offline: saved on this phone, will sync',late:'Time is up'}[sync]
  return <>
    <div className="xbar"><div className="w" style={{padding:0}}><div className="row sp">
      <div><div className={'timer'+(left!=null&&left<=300?' low':'')}>{left==null?'--:--':mmss(left)}</div><div className="sm" style={{color:sync==='offline'?'var(--warn)':'var(--mu)'}}>{syncTxt}</div></div>
      <div className="row"><span className="mu sm">{nAns}/{Q.length} answered</span>
      <button className="btn s line" onClick={()=>setPal(true)} style={{display:'none'}} id="palbtn">Palette</button>
      <button className="btn s" onClick={()=>setConfirm(true)}>Submit</button></div>
    </div></div></div>
    <style>{`@media(max-width:820px){#palbtn{display:inline-flex!important}}`}</style>
    <div style={{paddingTop:16}}>
      {left!=null&&left<=300&&left>0&&<div className="banner">Less than 5 minutes left. Your exam will be submitted automatically at zero.</div>}
      <div className="xwrap">
        <div className="card">
          <div className="row sp"><b className="mu">Question {cur+1} of {Q.length}</b>
            <button className={'btn s '+(a.m?'':'line')} onClick={()=>set({m:!a.m})}>{a.m?'Marked for review':'Mark for review'}</button></div>
          <div className="qtext" style={{marginTop:14}}><M t={q.text}/></div>
          {q.image_url&&<img src={q.image_url} alt="" style={{maxWidth:'100%',borderRadius:12,marginBottom:6}}/>}
          {order.map((orig,k)=><button key={orig} className={'opt'+(a.c===orig?' sel':'')} onClick={()=>set({c:a.c===orig?null:orig})} aria-pressed={a.c===orig}>
            <span className="bub">{L[k]}</span><span><M t={q.options[orig]}/></span></button>)}
          <div className="navbtns">
            <button className="btn line" disabled={cur===0} onClick={()=>setCur(cur-1)}>Previous</button>
            <button className="btn line" disabled={a.c==null} onClick={()=>set({c:null})}>Clear answer</button>
            <button className="btn" disabled={cur===Q.length-1} onClick={()=>setCur(cur+1)} style={{marginLeft:'auto'}}>Next</button>
          </div>
        </div>
        <div className="card palcard"><h3 style={{marginBottom:12}}>Questions</h3>{palette}</div>
      </div>
    </div>
    {pal&&<div className="modal" onClick={()=>setPal(false)}><div className="card" onClick={e=>e.stopPropagation()}><h3 style={{marginBottom:12}}>Questions</h3>{palette}<button className="btn line" style={{marginTop:16}} onClick={()=>setPal(false)}>Close</button></div></div>}
    {confirm&&<div className="modal"><div className="card">
      <h2 style={{marginTop:0}}>Submit your exam?</h2>
      <p>Answered: <b>{nAns}</b><br/>Not answered: <b>{Q.length-nAns}</b><br/>Marked for review: <b>{nMark}</b></p>
      <p className="mu sm">After you submit, you cannot change your answers.</p>
      {subErr&&<p className="err">{subErr}</p>}
      <div className="row"><button className="btn" disabled={busy} onClick={submit}>{busy?'Submitting…':'Yes, submit'}</button>
      <button className="btn line" disabled={busy} onClick={()=>setConfirm(false)}>Keep working</button></div>
    </div></div>}
  </>
}
