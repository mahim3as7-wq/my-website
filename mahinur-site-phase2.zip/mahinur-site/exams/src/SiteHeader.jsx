import React,{useState} from 'react'
import {WA} from './config'
// Same header as the portfolio: same logo, links, language switch (shared setting) and WhatsApp button.
const BN={"About":"পরিচিতি","Tutoring":"টিউটরিং","Health":"স্বাস্থ্য","Exams":"পরীক্ষা","Tips":"স্বাস্থ্য টিপস","YouTube":"ইউটিউব","Gallery":"গ্যালারি","FAQ":"প্রশ্নোত্তর","Contact":"যোগাযোগ","WhatsApp":"হোয়াটসঅ্যাপ","Menu":"মেনু"}
const ITEMS=[['About','about'],['Tutoring','tutoring'],['Health','health'],['Exams',null],['Tips','tips'],['YouTube','youtube'],['Gallery','gallery'],['FAQ','faq'],['Contact','contact']]
export const getLang=()=>{try{return localStorage.getItem('lang')==='bn'}catch{return false}}
export function SiteHeader({bn,setBn}){
  const [open,setOpen]=useState(false)
  const t=k=>bn?(BN[k]||k):k
  const flip=()=>{const v=!bn;setBn(v);try{localStorage.setItem('lang',v?'bn':'en')}catch{}}
  return <header className="site"><div className="w">
    <a className="logo" href="../#top">Mahinur Alam</a>
    <nav id="nv" className={open?'open':''}>
      {ITEMS.map(([k,h])=><a key={k} href={h?'../#'+h:'#/'} className={h?'':'cur'} onClick={()=>setOpen(false)}>{t(k)}</a>)}
    </nav>
    <button className="lang" onClick={flip}>{bn?'EN':'বাংলা'}</button>
    <button className="menu" aria-expanded={open} aria-controls="nv" onClick={()=>setOpen(!open)}>{t('Menu')}</button>
    <a className="btn fill" href={'https://wa.me/'+WA+'?text='+encodeURIComponent('Hello, I would like to know about your classes.')} target="_blank" rel="noopener">{t('WhatsApp')}</a>
  </div></header>
}
export function SiteFooter(){
  return <footer className="site"><div className="w"><span>&copy; 2026 Md. Mahinur Alam</span><span>MBBS, Sylhet MAG Osmani Medical College</span></div></footer>
}
