import React,{useMemo} from 'react'
import katex from 'katex'
import 'katex/contrib/mhchem'
import 'katex/dist/katex.min.css'
const esc=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
function render(t){
  return String(t==null?'':t).split(/(\$\$[^$]+\$\$|\$[^$\n]+\$)/g).map(p=>{
    if(p.startsWith('$$')&&p.endsWith('$$')&&p.length>4)return katex.renderToString(p.slice(2,-2),{throwOnError:false,displayMode:true})
    if(p.startsWith('$')&&p.endsWith('$')&&p.length>2)return katex.renderToString(p.slice(1,-1),{throwOnError:false})
    return esc(p)
  }).join('')
}
// Shows text; write formulas between dollar signs, e.g. $x^2$ or $\ce{H2O}$
export default function M({t}){const h=useMemo(()=>render(t),[t]);return <span dangerouslySetInnerHTML={{__html:h}}/>}
