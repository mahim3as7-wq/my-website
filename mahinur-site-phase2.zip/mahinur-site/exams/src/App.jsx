import React,{useEffect,useState} from 'react'
import {sb,configured,rpc,msg} from './supabase'
import {SiteHeader,SiteFooter,getLang} from './SiteHeader'
import Login from './Login'
import Student from './Student'
import Take from './Take'
import Admin from './Admin'

function useHash(){
  const [h,setH]=useState(location.hash||'#/')
  useEffect(()=>{const f=()=>setH(location.hash||'#/');addEventListener('hashchange',f);return()=>removeEventListener('hashchange',f)},[])
  return h.replace(/^#\/?/,'').split('/')
}
export const go=p=>{location.hash='#/'+p}

export default function App(){
  const [session,setSession]=useState(undefined)
  const [profile,setProfile]=useState(null)
  const [err,setErr]=useState('')
  const [bn,setBn]=useState(getLang())
  const parts=useHash()
  useEffect(()=>{
    if(!configured){setSession(null);return}
    sb.auth.getSession().then(({data})=>setSession(data.session))
    const {data:l}=sb.auth.onAuthStateChange((_e,s)=>setSession(s))
    return()=>l.subscription.unsubscribe()
  },[])
  useEffect(()=>{
    if(!session){setProfile(null);return}
    sb.from('profiles').select('*').eq('id',session.user.id).single()
      .then(({data,error})=>error?setErr(msg(error)):setProfile(data))
  },[session])

  const shell=(body,bare)=><>{!bare&&<SiteHeader bn={bn} setBn={setBn}/>}{body}{!bare&&<SiteFooter/>}</>
  const box=c=><div className="w" style={{paddingTop:60,minHeight:'60vh'}}>{c}</div>
  if(!configured)return shell(box(<><h1>Setup needed</h1><p className="mu">Open <code>exams/src/config.js</code> and paste your Supabase URL and publishable key, then rebuild.</p></>))
  if(session===undefined)return shell(box(<div className="skel"/>))
  if(!session)return shell(<Login/>)
  if(err)return shell(box(<><p className="err">{err}</p><button className="btn line" onClick={()=>sb.auth.signOut()}>Sign out</button></>))
  if(!profile)return shell(box(<div className="skel"/>))
  if(profile.blocked)return shell(box(<><h1>Account blocked</h1><p className="mu">Please contact the teacher.</p><button className="btn line" onClick={()=>sb.auth.signOut()}>Sign out</button></>))

  const isAdmin=profile.role==='admin'
  const page=parts[0]||''
  const inExam=page==='attempt'
  const body=<>
    {!inExam&&<div className="subbar"><div className="w"><nav className="n">
      <a href="#/" className={page===''||page==='exam'||page==='result'?'on':''}>My exams</a>
      {isAdmin&&<a href="#/admin" className={page==='admin'?'on':''}>Admin panel</a>}
      <span className="sp1"/>
      <span className="mu sm">{profile.display_name}</span>
      <button className="lnk" onClick={()=>sb.auth.signOut()}>Sign out</button>
    </nav></div></div>}
    <main className="w">
      {page==='admin'?(isAdmin?<Admin tab={parts[1]||'home'}/>:<p className="err">Only the teacher can open this page.</p>)
       :page==='attempt'?<Take id={parts[1]}/>
       :<Student page={page} id={parts[1]} profile={profile} setProfile={setProfile}/>}
    </main>
  </>
  return shell(body,inExam)
}
