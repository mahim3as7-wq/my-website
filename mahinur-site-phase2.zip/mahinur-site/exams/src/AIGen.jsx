import React,{useEffect,useRef,useState,useCallback} from 'react'
import {sb,rpc,msg,aiCall} from './supabase'
import M from './Math'

const L='ABCD'
const SUBJECTS=['Physics','Chemistry','Biology','Math','English','GK','ICT','Other']
const MAX_PAGES=100            // most pages one job may use (keeps cost predictable)
const MAX_PHOTO=1800           // photo is shrunk to this many pixels wide/high

async function shrinkPhoto(file){
  const bmp=await createImageBitmap(file)
  const k=Math.min(1,MAX_PHOTO/Math.max(bmp.width,bmp.height))
  const c=document.createElement('canvas');c.width=Math.round(bmp.width*k);c.height=Math.round(bmp.height*k)
  c.getContext('2d').drawImage(bmp,0,0,c.width,c.height)
  return await new Promise((ok,no)=>c.toBlob(b=>b?ok(b):no(new Error('Could not read this photo')),'image/jpeg',.85))
}
const up=async(path,blob,type)=>{const {error}=await sb.storage.from('ai-sources').upload(path,blob,{contentType:type,upsert:true});if(error)throw error}

export default function AIGen({QForm}){
  const [f,setF]=useState({kind:'topic',subject:'Biology',topic:'',difficulty:'medium',style:'admission',language:'english',count:10,perChunk:5,pagesPer:3,from:1,to:3,file:null})
  const [usage,setUsage]=useState(null)
  const [run,setRun]=useState(null)        // {jobId,total,done,made,skipped,errors,msg,stop}
  const [note,setNote]=useState('')
  const [unfinished,setUnfinished]=useState([])
  const stop=useRef(false)
  const set=(k,v)=>setF(p=>({...p,[k]:v}))

  const loadMeta=useCallback(async()=>{
    try{setUsage(await rpc('ai_usage_summary'))}catch{}
    const {data}=await sb.from('ai_jobs').select('id,subject,topic,kind,file_name,created_at,ai_chunks(status)').eq('status','running').order('created_at',{ascending:false}).limit(5)
    setUnfinished((data||[]).filter(j=>j.ai_chunks.some(c=>c.status!=='done')))
  },[])
  useEffect(()=>{loadMeta()},[loadMeta])

  // ---- process chunks one by one, so the page never freezes
  async function process(jobId){
    stop.current=false
    const {data:chunks}=await sb.from('ai_chunks').select('idx,status').eq('job_id',jobId).order('idx')
    const todo=chunks.filter(c=>c.status!=='done')
    let done=chunks.length-todo.length,made=0,skipped=0,errors=0
    setRun({jobId,total:chunks.length,done,made,skipped,errors,msg:'Working...'})
    for(const c of todo){
      if(stop.current){setRun(r=>({...r,msg:'Stopped. You can continue later.',finished:true}));loadMeta();return}
      try{
        const r=await aiCall({mode:'chunk',job_id:jobId,chunk_idx:c.idx})
        made+=r.made||0;skipped+=r.skipped||0;done++
      }catch(e){
        errors++
        if(e.code==='cap'||e.code==='rate'){setRun({jobId,total:chunks.length,done,made,skipped,errors,msg:e.message,finished:true});loadMeta();return}
        setRun(r=>({...r,errors,msg:'Part '+(c.idx+1)+' failed: '+e.message}))
      }
      setRun({jobId,total:chunks.length,done,made,skipped,errors,msg:'Working...'})
    }
    await sb.from('ai_jobs').update({status:errors?'running':'done'}).eq('id',jobId)
    setRun({jobId,total:chunks.length,done,made,skipped,errors,finished:true,
      msg:errors?'Finished with '+errors+' failed part(s). Tap "Continue" to retry them.':'Done. Review the drafts below.'})
    loadMeta();window.dispatchEvent(new Event('drafts-changed'))
  }

  async function start(){
    setNote('')
    if(!f.subject.trim())return setNote('Choose a subject.')
    if(f.kind==='topic'&&!f.topic.trim())return setNote('Type the topic name.')
    if(f.kind!=='topic'&&!f.file)return setNote(f.kind==='pdf'?'Choose the PDF file.':'Choose the photo.')
    try{
      setRun({total:0,done:0,made:0,skipped:0,errors:0,msg:'Preparing...'})
      const {data:{user}}=await sb.auth.getUser()
      let chunks=[],perChunk=+f.perChunk,pdf=null,fileName=null,from=null,to=null
      if(f.kind==='topic'){
        const total=Math.max(1,Math.min(60,+f.count)),parts=Math.ceil(total/10)
        perChunk=Math.ceil(total/parts)   // equal parts, at most 10 each (may give 1-2 extra, never fewer)
        for(let i=0;i<parts;i++)chunks.push({idx:i})
      }else if(f.kind==='image'){
        perChunk=Math.max(1,Math.min(15,+f.count));fileName=f.file.name;chunks=[{idx:0,page_from:1,page_to:1}]
      }else{
        const {PDFDocument}=await import('pdf-lib')
        pdf=await PDFDocument.load(await f.file.arrayBuffer(),{ignoreEncryption:true})
        const n=pdf.getPageCount();from=Math.max(1,+f.from||1);to=Math.min(n,+f.to||n)
        if(from>to)throw new Error('The first page must not be after the last page. This PDF has '+n+' pages.')
        if(to-from+1>MAX_PAGES)throw new Error('Please choose at most '+MAX_PAGES+' pages at a time.')
        const step=Math.max(1,Math.min(5,+f.pagesPer||3));fileName=f.file.name
        for(let p=from,i=0;p<=to;p+=step,i++)chunks.push({idx:i,page_from:p,page_to:Math.min(to,p+step-1)})
        perChunk=Math.max(1,Math.min(15,+f.perChunk))
      }
      const {data:job,error:je}=await sb.from('ai_jobs').insert({created_by:user.id,kind:f.kind,subject:f.subject.trim(),topic:f.topic.trim(),difficulty:f.difficulty,style:f.style,language:f.language,per_chunk:perChunk,page_from:from,page_to:to,file_name:fileName}).select().single()
      if(je)throw je
      // upload each piece of the source (private storage) so it can be retried or regenerated later
      const rows=[]
      for(const [k,c] of chunks.entries()){
        let path=null
        if(f.kind==='image'){path=job.id+'/0.jpg';await up(path,await shrinkPhoto(f.file),'image/jpeg')}
        if(f.kind==='pdf'){
          const part=await (await import('pdf-lib')).PDFDocument.create()
          const pages=await part.copyPages(pdf,Array.from({length:c.page_to-c.page_from+1},(_,i)=>c.page_from-1+i))
          pages.forEach(p=>part.addPage(p))
          path=job.id+'/'+c.idx+'.pdf';await up(path,new Blob([await part.save()],{type:'application/pdf'}),'application/pdf')
        }
        rows.push({job_id:job.id,idx:c.idx,page_from:c.page_from||null,page_to:c.page_to||null,source_path:path})
        setRun(r=>({...r,msg:'Preparing pages... '+(k+1)+'/'+chunks.length}))
      }
      const {error:ce}=await sb.from('ai_chunks').insert(rows)
      if(ce)throw ce
      await process(job.id)
    }catch(e){setRun(null);setNote(msg(e))}
  }

  const pct=run&&run.total?Math.round(run.done/run.total*100):0
  const busy=run&&!run.finished
  return <>
    <h1>AI question generator</h1>
    <p className="mu">Give a topic name, a book page photo or a chapter PDF. The AI writes <b>drafts</b>. Students never see drafts. You review them below, then approve.</p>
    {usage&&<p className="mu sm">AI use this month: {usage.month_tokens.toLocaleString()} of {usage.monthly_cap.toLocaleString()} tokens · calls in the last hour: {usage.calls_last_hour} of {usage.hourly_cap}</p>}
    <div className="card" style={{margin:'14px 0'}}>
      <div className="row" style={{marginBottom:14}}>
        {[['topic','Topic name'],['image','Book page photo'],['pdf','Chapter PDF']].map(([k,v])=><button key={k} className={'btn s '+(f.kind===k?'':'line')} onClick={()=>set('kind',k)} disabled={busy}>{v}</button>)}
      </div>
      <div className="three">
        <label className="f">Subject (pick, or type a new one)<input type="text" list="aisub" value={f.subject} onChange={e=>set('subject',e.target.value)}/><datalist id="aisub">{SUBJECTS.map(s=><option key={s}>{s}</option>)}</datalist></label>
        <label className="f">Topic{f.kind==='topic'?'':' (optional)'}<input type="text" value={f.topic} onChange={e=>set('topic',e.target.value)} placeholder="e.g. Cell structure"/></label>
        <label className="f">Difficulty<select value={f.difficulty} onChange={e=>set('difficulty',e.target.value)}><option>easy</option><option>medium</option><option>hard</option></select></label>
      </div>
      <div className="two">
        <label className="f">Style<select value={f.style} onChange={e=>set('style',e.target.value)}><option value="admission">Admission-test MCQ</option><option value="conceptual">Conceptual</option><option value="numerical">Numerical</option><option value="assertion">Assertion-reason</option></select></label>
        <label className="f">Language<select value={f.language} onChange={e=>set('language',e.target.value)}><option value="english">English</option><option value="bangla">Bangla</option><option value="both">Both (English and Bangla)</option></select></label>
      </div>
      {f.kind==='topic'&&<label className="f">How many questions (up to 60)<input type="number" min="1" max="60" value={f.count} onChange={e=>set('count',e.target.value)}/></label>}
      {f.kind==='image'&&<><label className="f">Photo of the page<input type="file" accept="image/*" onChange={e=>set('file',e.target.files[0]||null)}/></label>
        <label className="f">How many questions (up to 15)<input type="number" min="1" max="15" value={f.count} onChange={e=>set('count',e.target.value)}/></label></>}
      {f.kind==='pdf'&&<><label className="f">PDF file<input type="file" accept="application/pdf" onChange={e=>set('file',e.target.files[0]||null)}/></label>
        <div className="three"><label className="f">From page<input type="number" min="1" value={f.from} onChange={e=>set('from',e.target.value)}/></label>
          <label className="f">To page (up to {MAX_PAGES} pages)<input type="number" min="1" value={f.to} onChange={e=>set('to',e.target.value)}/></label>
          <label className="f">Pages per section (1 to 5)<input type="number" min="1" max="5" value={f.pagesPer} onChange={e=>set('pagesPer',e.target.value)}/></label></div>
        <label className="f">Questions per section (up to 15)<input type="number" min="1" max="15" value={f.perChunk} onChange={e=>set('perChunk',e.target.value)}/></label></>}
      <p className="sm mu">{f.kind==='topic'?'Without a source, the AI uses well-known textbook knowledge only. Always check the answers.':'Questions are written only from the pages you give, and each keeps its page number.'}</p>
      <div className="row"><button className="btn" onClick={start} disabled={busy}>{busy?'Working...':'Generate drafts'}</button>
        {busy&&<button className="btn line" onClick={()=>{stop.current=true}}>Stop after this part</button>}</div>
      {note&&<p className="err" style={{marginTop:12}}>{note}</p>}
      {run&&<div style={{marginTop:16}}>
        <div style={{height:10,background:'var(--line)',borderRadius:99,overflow:'hidden'}}><div style={{height:'100%',width:pct+'%',background:'var(--gold)',transition:'width .4s'}}/></div>
        <p className="sm" style={{margin:'8px 0 0'}}>{run.total?run.done+' of '+run.total+' parts · ':''}{run.made} drafts made{run.skipped?' · '+run.skipped+' duplicates or invalid dropped':''}{run.errors?' · '+run.errors+' failed':''}</p>
        <p className={'sm '+(run.errors&&run.finished?'err':'mu')} style={{margin:'4px 0 0'}}>{run.msg}</p>
      </div>}
    </div>
    {unfinished.length>0&&!busy&&<div className="card" style={{marginBottom:14}}><h3>Unfinished jobs</h3>
      {unfinished.map(j=><div key={j.id} className="row sp" style={{marginTop:10}}><span className="sm">{j.subject}{j.topic?' · '+j.topic:''} · {j.kind}{j.file_name?' · '+j.file_name:''} · {j.ai_chunks.filter(c=>c.status==='done').length}/{j.ai_chunks.length} parts done</span><button className="btn s" onClick={()=>process(j.id)}>Continue</button></div>)}</div>}
    <Review QForm={QForm}/>
  </>
}

/* ------------------------------ review list ------------------------------ */
function Review({QForm}){
  const [rows,setRows]=useState(null),[err,setErr]=useState(''),[sel,setSel]=useState(new Set()),[ed,setEd]=useState(null),[bz,setBz]=useState(''),[note,setNote]=useState('')
  const load=useCallback(async()=>{
    const {data,error}=await sb.from('questions').select('*').eq('status','draft').order('created_at',{ascending:false}).order('source_page',{ascending:true,nullsFirst:false}).limit(500)
    error?setErr(error.message):(setRows(data),setErr(''))
  },[])
  useEffect(()=>{load();const h=()=>load();window.addEventListener('drafts-changed',h);return()=>window.removeEventListener('drafts-changed',h)},[load])
  const flip=id=>setSel(s=>{const n=new Set(s);n.has(id)?n.delete(id):n.add(id);return n})
  const ids=[...sel]
  const approve=async()=>{const {error}=await sb.from('questions').update({status:'approved'}).in('id',ids);if(error)throw error}
  const act=async(label,fn)=>{setBz(label);setNote('');try{await fn()}catch(e){setNote(msg(e))}setBz('')}
  const del=ids1=>act('del',async()=>{if(!confirm('Delete '+ids1.length+' draft(s)?'))return;const {error}=await sb.from('questions').delete().in('id',ids1);if(error)throw error;setSel(new Set());await load()})
  const regen=id=>act('re'+id,async()=>{await aiCall({mode:'regenerate',question_id:id});await load()})
  const makeExam=()=>act('exam',async()=>{await approve();sessionStorage.setItem('prefillQids',JSON.stringify(ids));location.hash='#/admin/exams'})
  return <>
    <div className="row sp" style={{marginTop:28}}><h2 style={{margin:0}}>Review drafts{rows?' ('+rows.length+')':''}</h2>
      {rows&&rows.length>0&&<button className="btn s line" onClick={()=>setSel(sel.size===rows.length?new Set():new Set(rows.map(r=>r.id)))}>{sel.size===rows.length?'Untick all':'Tick all'}</button>}</div>
    <p className="mu sm">Tick the ones you want. Edit anything, delete, or regenerate one. Drafts are invisible to students until you approve them.</p>
    {sel.size>0&&<div className="card" style={{position:'sticky',top:70,zIndex:5,margin:'10px 0'}}><div className="row"><b>{sel.size} selected</b>
      <button className="btn s" disabled={!!bz} onClick={makeExam}>Create exam from selected questions</button>
      <button className="btn s line" disabled={!!bz} onClick={()=>act('ap',async()=>{await approve();setSel(new Set());await load()})}>Approve only</button>
      <button className="btn s bad" disabled={!!bz} onClick={()=>del(ids)}>Delete</button></div></div>}
    {note&&<p className="err">{note}</p>}{err&&<p className="err">{err}</p>}
    {!rows?<div className="skel"/>:!rows.length?<div className="empty card"><h3>No drafts waiting</h3><p>Generate some above. They will appear here for your review.</p></div>
    :rows.map(q=><div className="card" key={q.id} style={{marginBottom:10,borderColor:sel.has(q.id)?'var(--gold)':undefined}}>
      <div className="row sp"><label className="row" style={{cursor:'pointer'}}><input type="checkbox" checked={sel.has(q.id)} onChange={()=>flip(q.id)} style={{width:22,height:22}}/>
        <span className="chip gold">{q.subject}</span>{q.topic&&<span className="chip">{q.topic}</span>}<span className="chip">{q.difficulty}</span>{q.source&&<span className="chip">{q.source}</span>}</label>
        <div className="row"><button className="btn s line" onClick={()=>setEd({...q,image_url:q.image_url||''})}>Edit</button>
          <button className="btn s line" disabled={bz==='re'+q.id||!q.job_id} onClick={()=>regen(q.id)}>{bz==='re'+q.id?'Regenerating...':'Regenerate'}</button>
          <button className="btn s bad" onClick={()=>del([q.id])}>Delete</button></div></div>
      <p style={{margin:'10px 0 6px',whiteSpace:'pre-wrap'}}><M t={q.text}/></p>
      {q.options.map((o,i)=><div key={i} className="sm" style={{color:i===q.correct_index?'var(--ok)':'var(--mu)'}}>{L[i]}) <M t={o}/>{i===q.correct_index?'  (correct)':''}</div>)}
      {q.explanation&&<p className="sm" style={{margin:'8px 0 0'}}><b>Why:</b> <M t={q.explanation}/></p>}
    </div>)}
    {ed&&<QForm q={ed} close={()=>setEd(null)} saved={()=>{setEd(null);load()}}/>}
  </>
}
