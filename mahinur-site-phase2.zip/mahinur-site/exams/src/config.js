// Paste your two Supabase values between the quotes (Project Settings > API).
// The "publishable" key is designed to be public, so it is safe here.
export const SUPABASE_URL = "PASTE-PROJECT-URL-HERE";
export const SUPABASE_KEY = "PASTE-PUBLISHABLE-KEY-HERE";
// Same WhatsApp number as the portfolio
export const WA = "8801632673638";
