import React,{useState} from 'react'
import {sb,msg} from './supabase'
export default function Login(){
  const [mode,setMode]=useState('in'),[email,setEmail]=useState(''),[pw,setPw]=useState(''),[name,setName]=useState('')
  const [note,setNote]=useState(''),[bad,setBad]=useState(false),[busy,setBusy]=useState(false)
  const say=(m,b)=>{setNote(m);setBad(!!b)}
  const google=()=>sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.href.split('#')[0]}}).then(({error})=>error&&say(msg(error),1))
  const submit=async e=>{
    e.preventDefault();setBusy(true);say('')
    try{
      if(mode==='up'){
        if(pw.length<8)throw new Error('Password must be at least 8 characters.')
        const {data,error}=await sb.auth.signUp({email,password:pw,options:{data:{full_name:name.trim()},emailRedirectTo:location.href.split('#')[0]}})
        if(error)throw error
        if(!data.session)say('Almost done! We sent a verification link to your email. Click it, then come back and sign in.')
      }else if(mode==='reset'){
        const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.href.split('#')[0]})
        if(error)throw error;say('If that email has an account, a reset link is on its way.')
      }else{
        const {error}=await sb.auth.signInWithPassword({email,password:pw})
        if(error)throw error
      }
    }catch(x){say(/Invalid login/i.test(msg(x))?'Wrong email or password, or your email is not verified yet.':msg(x),1)}
    setBusy(false)
  }
  return <div className="w" style={{maxWidth:440,paddingTop:50}}>
    <a href="../" className="mu sm">&larr; Back to site</a>
    <h1 style={{margin:'14px 0 6px'}}>Mahinur Exams</h1>
    <p className="mu">Sign in to take exams and see your results.</p>
    <div className="card">
      <button className="btn line" style={{width:'100%'}} onClick={google}>Continue with Google</button>
      <p className="mu sm" style={{textAlign:'center',margin:'14px 0'}}>or use your email</p>
      <form onSubmit={submit}>
        {mode==='up'&&<label className="f">Your name<input type="text" value={name} onChange={e=>setName(e.target.value)} required maxLength={60} autoComplete="name"/></label>}
        <label className="f">Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email"/></label>
        {mode!=='reset'&&<label className="f">Password<input type="password" value={pw} onChange={e=>setPw(e.target.value)} required autoComplete={mode==='up'?'new-password':'current-password'}/></label>}
        <button className="btn" style={{width:'100%'}} disabled={busy}>{mode==='up'?'Create account':mode==='reset'?'Send reset link':'Sign in'}</button>
      </form>
      {note&&<p className={bad?'err':'ok'} style={{marginTop:12}}>{note}</p>}
      <p className="sm mu" style={{marginTop:14}}>
        {mode!=='in'&&<a href="#/" onClick={e=>{e.preventDefault();setMode('in');say('')}}>Sign in</a>}
        {mode==='in'&&<><a href="#/" onClick={e=>{e.preventDefault();setMode('up');say('')}}>Create an account</a> · <a href="#/" onClick={e=>{e.preventDefault();setMode('reset');say('')}}>Forgot password?</a></>}
      </p>
    </div>
    <p className="sm mu" style={{marginTop:14}}>Privacy: we store only your name, email and exam results. Only the teacher can see them.</p>
  </div>
}
