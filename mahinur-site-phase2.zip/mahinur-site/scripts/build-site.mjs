import {cpSync,mkdirSync} from 'node:fs'
mkdirSync('dist',{recursive:true})
for(const f of ['index.html','admin.html','config.js'])cpSync(f,'dist/'+f)
console.log('Site ready in dist/: portfolio at /, exams at /exams/')
