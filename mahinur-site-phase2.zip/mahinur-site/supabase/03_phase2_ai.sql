-- =====================================================================
-- Mahinur Exams - Phase 2 (AI question generation)
-- Run AFTER 01_schema.sql. Supabase > SQL Editor > New query > paste > Run.
-- AI drafts are saved with status 'draft'. Students can never see drafts,
-- and a draft can never be put into an exam until you approve it.
-- =====================================================================

alter table public.questions
  add column if not exists source_page int,
  add column if not exists job_id uuid,
  add column if not exists chunk_idx int;

-- one row per "Generate" click
create table public.ai_jobs (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('topic','image','pdf')),
  subject text not null,
  topic text not null default '',
  difficulty text not null default 'medium' check (difficulty in ('easy','medium','hard')),
  style text not null default 'admission' check (style in ('admission','conceptual','numerical','assertion')),
  language text not null default 'english' check (language in ('english','bangla','both')),
  per_chunk int not null default 5 check (per_chunk between 1 and 15),
  page_from int, page_to int,
  file_name text,
  status text not null default 'running' check (status in ('running','done','cancelled')),
  created_at timestamptz not null default now()
);
alter table public.ai_jobs enable row level security;
create policy ai_jobs_admin on public.ai_jobs for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- a big PDF is cut into small chunks, handled one by one (so nothing freezes)
create table public.ai_chunks (
  job_id uuid not null references public.ai_jobs(id) on delete cascade,
  idx int not null,
  page_from int, page_to int,
  source_path text,
  status text not null default 'pending' check (status in ('pending','running','done','error')),
  made int not null default 0,
  skipped int not null default 0,
  error text,
  primary key (job_id, idx)
);
alter table public.ai_chunks enable row level security;
create policy ai_chunks_admin on public.ai_chunks for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- every call to the AI is logged (for the rate limit and the monthly cap)
create table public.ai_log (
  id bigserial primary key,
  user_id uuid,
  job_id uuid,
  at timestamptz not null default now(),
  in_tokens int not null default 0,
  out_tokens int not null default 0
);
alter table public.ai_log enable row level security;
create policy ai_log_admin_read on public.ai_log for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.ai_log from authenticated, anon;

-- the limits you control
create table public.ai_settings (
  id boolean primary key default true check (id),
  monthly_token_cap bigint not null default 1500000 check (monthly_token_cap >= 0),
  hourly_call_cap int not null default 40 check (hourly_call_cap >= 0)
);
insert into public.ai_settings default values;
alter table public.ai_settings enable row level security;
create policy ai_settings_admin on public.ai_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- usage numbers for the admin screen
create function public.ai_usage_summary() returns jsonb
language plpgsql security definer set search_path = public as $$
declare s public.ai_settings;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  select * into s from public.ai_settings;
  return jsonb_build_object(
    'month_tokens', coalesce((select sum(in_tokens + out_tokens) from public.ai_log where at >= date_trunc('month', now())), 0),
    'monthly_cap', s.monthly_token_cap,
    'calls_last_hour', (select count(*) from public.ai_log where at >= now() - interval '1 hour'),
    'hourly_cap', s.hourly_call_cap);
end $$;
revoke execute on function public.ai_usage_summary() from public, anon, authenticated;
grant execute on function public.ai_usage_summary() to authenticated;

-- RULE: only approved questions can go into an exam
create function public.check_question_approved() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.questions where id = new.question_id and status = 'approved') then
    raise exception 'Only approved questions can be added to an exam. Approve the draft first.';
  end if;
  return new;
end $$;
revoke execute on function public.check_question_approved() from public, anon, authenticated;
create trigger exam_questions_approved before insert on public.exam_questions
  for each row execute function public.check_question_approved();

-- private storage for the pages/photos you give the AI (only you can open them)
insert into storage.buckets (id, name, public) values ('ai-sources', 'ai-sources', false)
  on conflict (id) do nothing;
create policy aisrc_admin_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'ai-sources' and public.is_admin());
create policy aisrc_admin_select on storage.objects for select to authenticated
  using (bucket_id = 'ai-sources' and public.is_admin());
create policy aisrc_admin_delete on storage.objects for delete to authenticated
  using (bucket_id = 'ai-sources' and public.is_admin());
