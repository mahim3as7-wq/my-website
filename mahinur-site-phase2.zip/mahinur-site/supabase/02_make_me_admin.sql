-- OPTIONAL. You normally do NOT need this: mahim3as7@gmail.com becomes admin automatically.
-- Only run it if the Admin button does not appear after you signed in with that email.
update public.profiles
   set role = 'admin'
 where id = (select id from auth.users where lower(email) = 'mahim3as7@gmail.com' and email_confirmed_at is not null);
