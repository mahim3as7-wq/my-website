import * as F from './index.ts'
import assert from 'node:assert/strict'
let pass=0;const ok=(c,m)=>{assert.ok(c,m);pass++;console.log('ok -',m)}

// ---- pure helpers
ok(F.similar('Which organelle is the powerhouse of the cell?','Which organelle is called the powerhouse of the cell?'),'near-duplicate detected')
ok(!F.similar('Which gas is released during photosynthesis?','Which gas is absorbed during respiration?')&&!F.similar('What is the SI unit of force?','Which organelle is called the powerhouse of the cell?'),'different questions kept')
const job={subject:'Biology',topic:'Cell',difficulty:'medium',style:'admission',language:'english',per_chunk:3,kind:'pdf',file_name:'Ch2.pdf',id:'j1'}
const good={question:'Q?',options:['a','b','c','d'],correct_index:2,explanation:'e',topic:'T',difficulty:'hard',page:2}
const r=F.cleanQuestion(good,job,12);ok(r&&r.source_page===13&&r.source==='Ch2.pdf, p.13'&&r.status==='draft'&&r.difficulty==='hard','page number mapped to real PDF page (12+2-1=13), status draft')
ok(F.cleanQuestion({...good,options:['a','a','c','d']},job,1)===null,'duplicate options rejected')
ok(F.cleanQuestion({...good,options:['a','b','c']},job,1)===null,'3 options rejected')
ok(F.cleanQuestion({...good,correct_index:4},job,1)===null,'bad correct index rejected')
ok(F.cleanQuestion({...good,options:['a','b','c','']},job,1)===null,'empty option rejected')
const pr=F.buildPrompt({...job,language:'both',style:'assertion'},{count:4,hasSource:true,avoid:['old q']})
ok(pr.system.includes('ONLY facts that appear in the supplied material')&&pr.system.includes('Assertion')&&pr.system.includes('বাংলা')&&pr.user.includes('old q'),'prompt: source-only rule, style, bilingual, avoid-list')
ok(F.buildPrompt(job,{count:2,hasSource:false}).system.includes('not sure a fact is correct'),'topic-only prompt warns against guessing')
ok(F.toBase64(new Uint8Array([72,105]))==='SGk=','base64')

// ---- fake db + fake Claude
function mk(over={}){
  const s={admin:true,settings:{monthly_token_cap:1000,hourly_call_cap:3},month:0,hour:0,
    job:{...job,status:'running'},chunks:{0:{idx:0,status:'pending',source_path:'j1/0.pdf',page_from:10,page_to:12}},
    qs:[],log:[],existing:[],jobStatus:'running',...over}
  const db={
    isAdmin:async()=>s.admin,getSettings:async()=>s.settings,monthTokens:async()=>s.month,callsLastHour:async()=>s.hour,
    getJob:async()=>s.job,getChunk:async(j,i)=>s.chunks[i]||null,setChunk:async(j,i,p)=>{Object.assign(s.chunks[i],p)},
    getQuestion:async id=>s.qs.find(q=>q.id===id)||null,updateQuestion:async(id,p)=>{Object.assign(s.qs.find(q=>q.id===id),p)},
    existingTexts:async()=>s.existing,insertQuestions:async rows=>{rows.forEach((r,i)=>s.qs.push({id:'q'+s.qs.length+i,...r}))},
    logUsage:async r=>s.log.push(r),download:async()=>new Uint8Array([1,2,3]),
    pendingChunks:async()=>Object.values(s.chunks).filter(c=>c.status!=='done').length,setJobStatus:async(id,st)=>{s.jobStatus=st}}
  return {s,db}
}
const claude=(qs,usage={input_tokens:900,output_tokens:300},status=200)=>async(url,init)=>{claude.last=JSON.parse(init.body);claude.hdr=init.headers
  return new Response(JSON.stringify(status===200?{content:[{type:'tool_use',name:'submit_questions',input:{questions:qs}}],usage}:{error:{message:'busy'}}),{status})}
const call=(m,body,auth='Bearer x')=>new Request('http://f',{method:'POST',headers:{authorization:auth,'content-type':'application/json'},body:JSON.stringify(body)})
const env=k=>({ANTHROPIC_API_KEY:'sk-test'}[k])
const Q=(t,p=1)=>({question:t,options:['w','x','y','z'],correct_index:0,explanation:'e',page:p})

{ // not admin
  const {db}=mk({admin:false});const r=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude([])});ok(r.status===403,'non-admin is refused (403)')}
{ // no key
  const {db}=mk();const r=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env:()=>undefined,db,fetch:claude([])});ok(r.status===500,'missing API key gives a clear error')}
{ // happy path + dedupe + page map
  const {s,db}=mk({existing:['Which organelle is the powerhouse of a cell today?']})
  const qs=[Q('What is the SI unit of force in physics?',1),Q('Which organelle is the powerhouse of a cell today?',2),Q('Name the control center of the cell nucleus',3),{question:'bad',options:['a'],correct_index:0}]
  const r=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude(qs)});const b=await r.json()
  ok(r.status===200&&b.made===2&&b.skipped===2,'2 saved, 1 duplicate + 1 invalid skipped')
  ok(s.qs.every(q=>q.status==='draft'&&q.job_id==='j1'),'everything saved as DRAFT')
  ok(s.qs.map(q=>q.source_page).join()==='10,12','source pages mapped to 10 and 12')
  ok(s.chunks[0].status==='done'&&s.jobStatus==='done'&&s.log.length===1&&s.log[0].in_tokens===900,'chunk done, job done, usage logged')
  ok(claude.hdr['x-api-key']==='sk-test'&&claude.last.tool_choice.name==='submit_questions'&&claude.last.messages[0].content[0].type==='document','sent key server-side, forced tool, PDF attached')
  const again=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude(qs)});ok((await again.json()).note==='already done'&&s.qs.length===2,'repeat call does not duplicate')}
{ // image
  const {db,s}=mk({job:{...job,kind:'image'}});await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude([Q('Photo question about mitosis stages?',1)])});ok(claude.last.messages[0].content[0].type==='image','photo is sent as an image')}
{ // topic only
  const {db}=mk({job:{...job,kind:'topic'},chunks:{0:{idx:0,status:'pending',source_path:null}}});await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude([Q('Topic only question about osmosis?')])});ok(claude.last.messages[0].content.length===1,'topic-only sends no file')}
{ // limits
  let {db}=mk({hour:3});let r=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude([])});ok(r.status===429&&(await r.json()).code==='rate','hourly limit blocks (429)')
  ;({db}=mk({month:1000}));r=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude([])});ok(r.status===429&&(await r.json()).code==='cap','monthly token cap blocks (429)')}
{ // AI error marks chunk error
  const {db,s}=mk();const r=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude([],{},529)});ok(r.status===502&&s.chunks[0].status==='error'&&/busy/.test(s.chunks[0].error),'AI outage: chunk marked error, message kept, nothing saved')}
{ // cancelled job
  const {db}=mk({job:{...job,status:'cancelled'}});const r=await F.handle(call('POST',{mode:'chunk',job_id:'j1',chunk_idx:0}),{env,db,fetch:claude([])});ok(r.status===409,'cancelled job refused')}
{ // regenerate
  const {db,s}=mk();s.qs.push({id:'qa',status:'draft',job_id:'j1',chunk_idx:0,text:'Old question text about cells and membranes',subject:'Biology'})
  let r=await F.handle(call('POST',{mode:'regenerate',question_id:'qa'}),{env,db,fetch:claude([Q('Brand new different question about chloroplast function?',1)])});ok((await r.json()).made===1&&/chloroplast/.test(s.qs[0].text)&&s.qs[0].status==='draft'&&s.qs.length===1,'regenerate replaces the draft in place')
  s.qs.push({id:'qb',status:'approved',job_id:'j1',text:'approved'});r=await F.handle(call('POST',{mode:'regenerate',question_id:'qb'}),{env,db,fetch:claude([])});ok(r.status===400,'approved questions cannot be regenerated')}
console.log('\nALL',pass,'CHECKS PASSED')
