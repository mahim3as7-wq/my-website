// Supabase Edge Function: generate-questions
// Called only by the admin panel. The Claude API key is read from the server secret
// ANTHROPIC_API_KEY and is never sent to any browser.
//
// What it enforces on the SERVER (so a browser cannot skip it):
//  - the caller must be the admin
//  - a per-hour call limit and a monthly token cap (both editable in the ai_settings table)
//  - questions are stored as DRAFTS only; nothing reaches students until the admin approves
//  - near-duplicate questions are dropped
//
// The logic is written against a small "db" interface so it can be tested without a real database.

export const MAX_COUNT = 15;

export const STYLE_TEXT: Record<string, string> = {
  admission:
    "Admission-test style: concise, tricky-but-fair MCQs of the kind used in medical and engineering admission tests in Bangladesh.",
  conceptual:
    "Conceptual style: test understanding of ideas and reasons, not memorised words.",
  numerical:
    "Numerical style: short calculation problems with clean numbers. The explanation must show the working in one or two lines.",
  assertion:
    "Assertion-Reason style: each question gives an Assertion (A) and a Reason (R) in the question text. The four options must be exactly: " +
    "'Both A and R are true and R is the correct explanation of A', 'Both A and R are true but R is not the correct explanation of A', " +
    "'A is true but R is false', 'A is false but R is true'.",
};

export function languageText(lang: string): string {
  if (lang === "bangla") return "Write the question, all four options and the explanation in Bangla. Keep formulas and standard symbols in LaTeX.";
  if (lang === "both")
    return "Write every question bilingually: the English text, then a line break, then the Bangla text. Each option must read 'English / বাংলা'. The explanation should be English then Bangla.";
  return "Write in clear English.";
}

export function buildPrompt(job: any, o: { count: number; hasSource: boolean; pages?: number; avoid?: string[]; replace?: string }) {
  const system =
    "You write multiple-choice questions for Bangladeshi students (SSC, HSC, medical and engineering admission). " +
    "Rules you must follow:\n" +
    "1. " + (o.hasSource
      ? "Use ONLY facts that appear in the supplied material. Do not add outside facts. If the material does not support a question, write fewer questions instead of inventing."
      : "No source material is supplied. Use only well-established textbook knowledge about the stated topic. If you are not sure a fact is correct, do not write a question about it.") + "\n" +
    "2. Every question has exactly four options and exactly one correct option. Distractors must be plausible and clearly wrong on a careful reading. Do not use 'all of the above' or 'none of the above'.\n" +
    "3. The explanation is short (one to three sentences) and says why the answer is correct.\n" +
    "4. Write formulas in LaTeX between single dollar signs, for example $x^2$; chemistry with $\\ce{H2O}$.\n" +
    "5. Never invent data, names, statistics or page numbers.\n" +
    "6. " + (STYLE_TEXT[job.style] || STYLE_TEXT.admission) + "\n" +
    "7. " + languageText(job.language) + "\n" +
    "8. Difficulty: " + job.difficulty + ".\n" +
    "9. Report the topic tag for each question (a short phrase)." +
    (o.hasSource ? "\n10. For each question give 'page': the page number WITHIN the supplied pages, where 1 is the first supplied page. If a photo, use 1." : "");
  let user = "Subject: " + job.subject + "\n" + (job.topic ? "Topic: " + job.topic + "\n" : "");
  user += "Write exactly " + o.count + " question" + (o.count === 1 ? "" : "s") + (o.hasSource ? " from the supplied material" : " on this topic") + ".";
  if (o.replace) user += "\nWrite a NEW question that is clearly different from this one: " + o.replace;
  if (o.avoid && o.avoid.length) user += "\nDo not repeat or closely paraphrase these existing questions:\n- " + o.avoid.slice(0, 60).join("\n- ");
  return { system, user };
}

export const TOOL = {
  name: "submit_questions",
  description: "Submit the finished multiple-choice questions.",
  input_schema: {
    type: "object",
    properties: {
      questions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            question: { type: "string" },
            options: { type: "array", items: { type: "string" }, minItems: 4, maxItems: 4 },
            correct_index: { type: "integer", minimum: 0, maximum: 3 },
            explanation: { type: "string" },
            topic: { type: "string" },
            difficulty: { type: "string", enum: ["easy", "medium", "hard"] },
            page: { type: "integer", minimum: 1 },
          },
          required: ["question", "options", "correct_index", "explanation"],
        },
      },
    },
    required: ["questions"],
  },
};

// ---------- text helpers ----------
export function words(s: string): Set<string> {
  return new Set(
    String(s || "").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter((w) => w.length > 2),
  );
}
export function similar(a: string, b: string, limit = 0.72): boolean {
  const A = words(a), B = words(b);
  if (!A.size || !B.size) return false;
  let inter = 0;
  for (const w of A) if (B.has(w)) inter++;
  return inter / (A.size + B.size - inter) >= limit;
}

export function parseToolInput(resp: any): any[] {
  const block = (resp && resp.content || []).find((c: any) => c.type === "tool_use" && c.name === "submit_questions");
  const qs = block && block.input && block.input.questions;
  return Array.isArray(qs) ? qs : [];
}

// validate one model question; returns a database row or null
export function cleanQuestion(q: any, job: any, pageBase: number | null) {
  if (!q || typeof q.question !== "string" || !q.question.trim()) return null;
  const opts = Array.isArray(q.options) ? q.options.map((o: any) => String(o ?? "").trim()) : [];
  if (opts.length !== 4 || opts.some((o: string) => !o)) return null;
  if (new Set(opts.map((o: string) => o.toLowerCase())).size !== 4) return null;
  const ci = q.correct_index;
  if (!Number.isInteger(ci) || ci < 0 || ci > 3) return null;
  const diff = ["easy", "medium", "hard"].includes(q.difficulty) ? q.difficulty : job.difficulty;
  let page: number | null = null;
  if (pageBase != null && Number.isInteger(q.page) && q.page >= 1) page = pageBase + q.page - 1;
  return {
    subject: job.subject,
    topic: String(q.topic || job.topic || "").trim().slice(0, 120),
    difficulty: diff,
    text: q.question.trim(),
    options: opts,
    correct_index: ci,
    explanation: String(q.explanation || "").trim(),
    source: job.file_name ? job.file_name + (page ? ", p." + page : "") : "",
    source_page: page,
    status: "draft",
  };
}

export function toBase64(bytes: Uint8Array): string {
  let s = "";
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) s += String.fromCharCode(...bytes.subarray(i, i + step));
  return btoa(s);
}

// ---------- the handler ----------
export interface Deps {
  env: (k: string) => string | undefined;
  db: any;
  fetch: typeof fetch;
}

const json = (body: unknown, status = 200, cors: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", ...cors } });

export async function handle(req: Request, deps: Deps): Promise<Response> {
  const cors = {
    "access-control-allow-origin": "*",
    "access-control-allow-headers": "authorization, x-client-info, apikey, content-type",
  };
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Use POST." }, 405, cors);
  const { db } = deps;

  // 1. only the admin
  const auth = req.headers.get("authorization") || "";
  if (!auth || !(await db.isAdmin(auth))) return json({ error: "Only the teacher can use this." }, 403, cors);

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Bad request." }, 400, cors); }
  const mode = body.mode;
  if (mode !== "chunk" && mode !== "regenerate") return json({ error: "Unknown mode." }, 400, cors);

  const key = deps.env("ANTHROPIC_API_KEY");
  if (!key) return json({ error: "The AI key is not set on the server yet (ANTHROPIC_API_KEY)." }, 500, cors);

  // 2. limits (enforced here, not in the browser)
  const set = await db.getSettings();
  if ((await db.callsLastHour()) >= set.hourly_call_cap)
    return json({ error: "Hourly AI limit reached. Please try again in a while.", code: "rate" }, 429, cors);
  if ((await db.monthTokens()) >= set.monthly_token_cap)
    return json({ error: "The monthly AI limit is used up. You can raise it in the ai_settings table.", code: "cap" }, 429, cors);

  // 3. what to generate
  let job: any, chunk: any = null, question: any = null, count: number;
  if (mode === "chunk") {
    job = await db.getJob(body.job_id);
    if (!job) return json({ error: "Job not found." }, 404, cors);
    chunk = await db.getChunk(body.job_id, body.chunk_idx);
    if (!chunk) return json({ error: "Chunk not found." }, 404, cors);
    if (chunk.status === "done") return json({ made: 0, skipped: 0, note: "already done" }, 200, cors);
    if (job.status === "cancelled") return json({ error: "This job was cancelled." }, 409, cors);
    count = Math.min(job.per_chunk, MAX_COUNT);
    await db.setChunk(job.id, chunk.idx, { status: "running", error: null });
  } else {
    question = await db.getQuestion(body.question_id);
    if (!question || question.status !== "draft") return json({ error: "Only drafts can be regenerated." }, 400, cors);
    job = question.job_id ? await db.getJob(question.job_id) : null;
    if (!job) return json({ error: "This question has no AI job to regenerate from." }, 400, cors);
    chunk = question.chunk_idx != null ? await db.getChunk(job.id, question.chunk_idx) : null;
    count = 1;
  }

  const fail = async (msg: string, status = 502, code?: string) => {
    if (mode === "chunk") await db.setChunk(job.id, chunk.idx, { status: "error", error: msg.slice(0, 300) });
    return json({ error: msg, code }, status, cors);
  };

  try {
    // 4. build the Claude request
    const hasSource = job.kind !== "topic" && !!(chunk && chunk.source_path);
    const avoid = await db.existingTexts(job.id, job.subject);
    const { system, user } = buildPrompt(job, {
      count, hasSource, avoid: avoid.slice(0, 60), replace: question ? question.text : undefined,
    });
    const content: any[] = [];
    if (hasSource) {
      const bytes: Uint8Array = await db.download(chunk.source_path);
      const data = toBase64(bytes);
      if (job.kind === "pdf") content.push({ type: "document", source: { type: "base64", media_type: "application/pdf", data } });
      else content.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data } });
    }
    content.push({ type: "text", text: user });

    const payload = {
      model: deps.env("CLAUDE_MODEL") || "claude-sonnet-5-5",
      max_tokens: 6000,
      system,
      tools: [TOOL],
      tool_choice: { type: "tool", name: "submit_questions" },
      messages: [{ role: "user", content }],
    };

    // 5. call Claude (one retry on busy/limit)
    let res: Response | null = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      res = await deps.fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
        body: JSON.stringify(payload),
      });
      if (res.status !== 429 && res.status < 500) break;
      await new Promise((r) => setTimeout(r, 1500));
    }
    if (!res || !res.ok) {
      let detail = "";
      try { detail = (await res!.json()).error?.message || ""; } catch { /* ignore */ }
      return await fail("The AI service returned an error" + (res ? " (" + res.status + ")" : "") + (detail ? ": " + detail : "") + ".");
    }
    const out = await res.json();
    await db.logUsage({ user_id: null, job_id: job.id, in_tokens: out.usage?.input_tokens || 0, out_tokens: out.usage?.output_tokens || 0 });

    // 6. validate, drop duplicates, save as drafts
    const pageBase = hasSource && chunk && chunk.page_from ? chunk.page_from : (hasSource ? 1 : null);
    const seen: string[] = [...avoid];
    const rows: any[] = [];
    let skipped = 0;
    for (const q of parseToolInput(out)) {
      const row = cleanQuestion(q, job, pageBase);
      if (!row || seen.some((t) => similar(t, row.text))) { skipped++; continue; }
      seen.push(row.text);
      rows.push({ ...row, job_id: job.id, chunk_idx: chunk ? chunk.idx : null });
    }

    if (mode === "regenerate") {
      if (!rows.length) return json({ error: "The AI did not produce a usable new question. Try again.", code: "empty" }, 200, cors);
      const r = rows[0];
      await db.updateQuestion(question.id, {
        topic: r.topic, difficulty: r.difficulty, text: r.text, options: r.options,
        correct_index: r.correct_index, explanation: r.explanation, source: r.source, source_page: r.source_page,
      });
      return json({ made: 1, skipped, in_tokens: out.usage?.input_tokens, out_tokens: out.usage?.output_tokens }, 200, cors);
    }

    if (rows.length) await db.insertQuestions(rows);
    await db.setChunk(job.id, chunk.idx, { status: "done", made: rows.length, skipped, error: null });
    if ((await db.pendingChunks(job.id)) === 0) await db.setJobStatus(job.id, "done");
    return json({ made: rows.length, skipped, in_tokens: out.usage?.input_tokens, out_tokens: out.usage?.output_tokens }, 200, cors);
  } catch (e) {
    return await fail("Something went wrong: " + (e && (e as Error).message ? (e as Error).message : String(e)), 500);
  }
}

// ---------- the real database adapter (used only when running on Supabase) ----------
export function makeDb(createClient: any, env: (k: string) => string | undefined) {
  const url = env("SUPABASE_URL")!;
  const admin = createClient(url, env("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const ok = (r: any) => { if (r.error) throw new Error(r.error.message); return r.data; };
  const monthStart = () => { const d = new Date(); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString(); };
  return {
    async isAdmin(authHeader: string) {
      const c = createClient(url, env("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
      const r = await c.rpc("is_admin");
      return !r.error && r.data === true;
    },
    async getSettings() { return ok(await admin.from("ai_settings").select("*").single()); },
    async monthTokens() {
      const rows = ok(await admin.from("ai_log").select("in_tokens,out_tokens").gte("at", monthStart()));
      return rows.reduce((a: number, r: any) => a + r.in_tokens + r.out_tokens, 0);
    },
    async callsLastHour() {
      const r = await admin.from("ai_log").select("id", { count: "exact", head: true }).gte("at", new Date(Date.now() - 3600_000).toISOString());
      if (r.error) throw new Error(r.error.message);
      return r.count || 0;
    },
    async getJob(id: string) { return ok(await admin.from("ai_jobs").select("*").eq("id", id).maybeSingle()); },
    async getChunk(job: string, idx: number) { return ok(await admin.from("ai_chunks").select("*").eq("job_id", job).eq("idx", idx).maybeSingle()); },
    async setChunk(job: string, idx: number, patch: any) { ok(await admin.from("ai_chunks").update(patch).eq("job_id", job).eq("idx", idx)); },
    async getQuestion(id: string) { return ok(await admin.from("questions").select("*").eq("id", id).maybeSingle()); },
    async updateQuestion(id: string, patch: any) { ok(await admin.from("questions").update(patch).eq("id", id)); },
    async existingTexts(jobId: string, subject: string) {
      const a = ok(await admin.from("questions").select("text").eq("job_id", jobId).limit(500));
      const b = ok(await admin.from("questions").select("text").eq("subject", subject).eq("status", "approved").limit(1500));
      return [...a, ...b].map((r: any) => r.text);
    },
    async insertQuestions(rows: any[]) { ok(await admin.from("questions").insert(rows)); },
    async logUsage(row: any) { ok(await admin.from("ai_log").insert(row)); },
    async download(path: string) {
      const r = await admin.storage.from("ai-sources").download(path);
      if (r.error) throw new Error("Could not read the uploaded file: " + r.error.message);
      return new Uint8Array(await r.data.arrayBuffer());
    },
    async pendingChunks(jobId: string) {
      const r = await admin.from("ai_chunks").select("idx", { count: "exact", head: true }).eq("job_id", jobId).neq("status", "done");
      if (r.error) throw new Error(r.error.message);
      return r.count || 0;
    },
    async setJobStatus(id: string, status: string) { ok(await admin.from("ai_jobs").update({ status }).eq("id", id)); },
  };
}

// Supabase starts the function here. (Skipped when the file is imported by the tests.)
// deno-lint-ignore no-explicit-any
const D: any = (globalThis as any).Deno;
if (D && D.serve) {
  const { createClient } = await import("npm:@supabase/supabase-js@2");
  const env = (k: string) => D.env.get(k);
  D.serve((req: Request) => handle(req, { env, db: makeDb(createClient, env), fetch }));
}
