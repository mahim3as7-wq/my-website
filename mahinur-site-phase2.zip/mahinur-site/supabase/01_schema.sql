-- =====================================================================
-- Mahinur Exams - Phase 1 database
-- Paste this whole file into Supabase > SQL Editor > New query > Run.
-- Safe rules: students can NEVER read the questions table directly.
-- They get questions without answers through functions below, and the
-- server (not the phone) keeps the timer and does all scoring.
-- =====================================================================

-- ---------- profiles ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Student',
  role text not null default 'student' check (role in ('student','admin')),
  blocked boolean not null default false,
  anonymous boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin' and not blocked) $$;

create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'full_name',''),
                           nullif(new.raw_user_meta_data->>'name',''),
                           nullif(split_part(new.email,'@',1),''), 'Student'))
  on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- The teacher's email is made admin automatically, but ONLY once that email is verified
-- (Google sign-in counts as verified; email sign-up counts after the verification link is clicked).
create function public.promote_admin() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if lower(new.email) = 'mahim3as7@gmail.com' and new.email_confirmed_at is not null then
    update public.profiles set role = 'admin' where id = new.id;
  end if;
  return new;
end $$;
create trigger on_auth_user_promote after insert or update of email_confirmed_at on auth.users
  for each row execute function public.promote_admin();

create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
-- students may change ONLY these two columns (never role or blocked)
revoke update on public.profiles from authenticated, anon;
grant update (display_name, anonymous) on public.profiles to authenticated;
revoke insert, delete on public.profiles from authenticated, anon;

-- ---------- question bank ----------
create table public.questions (
  id uuid primary key default gen_random_uuid(),
  subject text not null,
  topic text not null default '',
  difficulty text not null default 'medium' check (difficulty in ('easy','medium','hard')),
  text text not null,
  options jsonb not null check (jsonb_typeof(options) = 'array' and jsonb_array_length(options) = 4),
  correct_index smallint not null check (correct_index between 0 and 3),
  explanation text not null default '',
  source text not null default '',
  image_url text,
  status text not null default 'approved' check (status in ('draft','approved')),
  created_at timestamptz not null default now()
);
alter table public.questions enable row level security;
create policy questions_admin on public.questions for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
-- (no student policy on purpose)

-- ---------- exams ----------
create table public.exams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  topic text not null default '',
  kind text not null default 'practice' check (kind in ('live','practice')),
  marks_per_q numeric not null default 1 check (marks_per_q > 0),
  negative numeric not null default 0 check (negative >= 0),
  duration_min int not null default 30 check (duration_min between 1 and 600),
  starts_at timestamptz,
  ends_at timestamptz,
  max_attempts int not null default 1 check (max_attempts >= 0), -- 0 = unlimited
  shuffle boolean not null default false,
  results_mode text not null default 'instant' check (results_mode in ('instant','after_end')),
  published boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.exams enable row level security;
create policy exams_admin on public.exams for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy exams_student_read on public.exams for select to authenticated
  using (published);

create table public.exam_questions (
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete restrict,
  position int not null default 0,
  primary key (exam_id, question_id)
);
alter table public.exam_questions enable row level security;
create policy eq_admin on public.exam_questions for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- attempts & answers (written ONLY by the functions below) ----------
create table public.attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  started_at timestamptz not null default now(),
  deadline_at timestamptz not null,
  submitted_at timestamptz,
  status text not null default 'in_progress' check (status in ('in_progress','submitted')),
  qorder jsonb not null default '[]',
  score numeric, correct int, wrong int, skipped int
);
create unique index one_open_attempt on public.attempts(exam_id, student_id) where status = 'in_progress';
create index attempts_student on public.attempts(student_id);
alter table public.attempts enable row level security;
create policy attempts_select on public.attempts for select to authenticated
  using (student_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.attempts from authenticated, anon;

create table public.answers (
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  chosen smallint check (chosen between 0 and 3),
  marked boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (attempt_id, question_id)
);
alter table public.answers enable row level security;
create policy answers_select on public.answers for select to authenticated
  using (public.is_admin() or exists (select 1 from public.attempts a where a.id = attempt_id and a.student_id = auth.uid()));
revoke insert, update, delete on public.answers from authenticated, anon;

-- =====================================================================
-- Server-side functions
-- =====================================================================

-- internal: score one attempt (never callable from the browser)
create function public._score_attempt(p_attempt uuid) returns void
language plpgsql security definer set search_path = public as $$
declare a public.attempts; e public.exams; c int; w int; n int;
begin
  select * into a from public.attempts where id = p_attempt for update;
  if not found or a.status = 'submitted' then return; end if;
  select * into e from public.exams where id = a.exam_id;
  select count(*) into n from public.exam_questions where exam_id = a.exam_id;
  select count(*) filter (where an.chosen = q.correct_index),
         count(*) filter (where an.chosen is not null and an.chosen <> q.correct_index)
    into c, w
    from public.answers an join public.questions q on q.id = an.question_id
   where an.attempt_id = p_attempt
     and an.question_id in (select question_id from public.exam_questions where exam_id = a.exam_id);
  update public.attempts set status = 'submitted', submitted_at = least(now(), a.deadline_at),
         score = c * e.marks_per_q - w * e.negative, correct = c, wrong = w, skipped = n - c - w
   where id = p_attempt;
end $$;

-- internal: submit every attempt whose time has run out
create function public._finalize(p_uid uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in select id from public.attempts
            where status = 'in_progress' and deadline_at <= now() and (p_uid is null or student_id = p_uid)
  loop perform public._score_attempt(r.id); end loop;
end $$;

-- student: list of published exams with my progress
create function public.student_exams() returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Please sign in'; end if;
  perform public._finalize(auth.uid());
  return coalesce((select jsonb_agg(jsonb_build_object(
    'id', e.id, 'title', e.title, 'subject', e.subject, 'topic', e.topic, 'kind', e.kind,
    'marks_per_q', e.marks_per_q, 'negative', e.negative, 'duration_min', e.duration_min,
    'starts_at', e.starts_at, 'ends_at', e.ends_at, 'max_attempts', e.max_attempts,
    'results_mode', e.results_mode,
    'question_count', (select count(*) from public.exam_questions q where q.exam_id = e.id),
    'attempts', (select count(*) from public.attempts a where a.exam_id = e.id and a.student_id = auth.uid()),
    'open_attempt', (select a.id from public.attempts a where a.exam_id = e.id and a.student_id = auth.uid() and a.status = 'in_progress' limit 1),
    'last_attempt', (select a.id from public.attempts a where a.exam_id = e.id and a.student_id = auth.uid() and a.status = 'submitted' order by a.submitted_at desc limit 1)
  ) order by e.created_at desc) from public.exams e where e.published), '[]'::jsonb)
  || jsonb_build_array(jsonb_build_object('server_now', now()));
end $$;

-- student: begin (or resume) an attempt
create function public.start_attempt(p_exam uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare e public.exams; uid uuid := auth.uid(); a uuid; cnt int; dl timestamptz; ord jsonb;
begin
  if uid is null then raise exception 'Please sign in'; end if;
  if exists (select 1 from public.profiles where id = uid and blocked) then
    raise exception 'Your account is blocked. Please contact the teacher.'; end if;
  perform public._finalize(uid);
  select * into e from public.exams where id = p_exam and published;
  if not found then raise exception 'Exam not found'; end if;
  select id into a from public.attempts where exam_id = p_exam and student_id = uid and status = 'in_progress';
  if found then return a; end if;
  if e.kind = 'live' then
    if e.starts_at is not null and now() < e.starts_at then raise exception 'This exam has not started yet'; end if;
    if e.ends_at is not null and now() >= e.ends_at then raise exception 'This exam has ended'; end if;
  end if;
  select count(*) into cnt from public.attempts where exam_id = p_exam and student_id = uid;
  if e.max_attempts > 0 and cnt >= e.max_attempts then raise exception 'You have used all attempts for this exam'; end if;
  if not exists (select 1 from public.exam_questions where exam_id = p_exam) then raise exception 'This exam has no questions yet'; end if;
  dl := now() + make_interval(mins => e.duration_min);
  if e.kind = 'live' and e.ends_at is not null then dl := least(dl, e.ends_at); end if;
  select coalesce(jsonb_agg(question_id order by case when e.shuffle then random() end, position), '[]')
    into ord from public.exam_questions where exam_id = p_exam;
  insert into public.attempts(exam_id, student_id, deadline_at, qorder) values (p_exam, uid, dl, ord)
    on conflict (exam_id, student_id) where status = 'in_progress' do nothing
    returning id into a;
  if a is null then
    select id into a from public.attempts where exam_id = p_exam and student_id = uid and status = 'in_progress';
  end if;
  return a;
end $$;

-- student: load my attempt (questions WITHOUT correct answers)
create function public.get_attempt(p_attempt uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a public.attempts; e public.exams;
begin
  select * into a from public.attempts where id = p_attempt and student_id = auth.uid();
  if not found then raise exception 'Attempt not found'; end if;
  if a.status = 'in_progress' and a.deadline_at <= now() then
    perform public._score_attempt(a.id);
    select * into a from public.attempts where id = p_attempt;
  end if;
  select * into e from public.exams where id = a.exam_id;
  return jsonb_build_object(
    'id', a.id, 'status', a.status, 'deadline_at', a.deadline_at, 'server_now', now(),
    'exam', jsonb_build_object('id', e.id, 'title', e.title, 'marks_per_q', e.marks_per_q,
            'negative', e.negative, 'duration_min', e.duration_min, 'shuffle', e.shuffle),
    'questions', case when a.status = 'in_progress' then
      (select coalesce(jsonb_agg(jsonb_build_object('id', q.id, 'text', q.text, 'options', q.options, 'image_url', q.image_url) order by o.ord), '[]')
         from jsonb_array_elements_text(a.qorder) with ordinality o(qid, ord)
         join public.questions q on q.id = o.qid::uuid)
      else '[]'::jsonb end,
    'answers', (select coalesce(jsonb_object_agg(an.question_id, jsonb_build_object('c', an.chosen, 'm', an.marked)), '{}')
                  from public.answers an where an.attempt_id = a.id));
end $$;

-- student: autosave one answer (server checks time and ownership)
create function public.save_answer(p_attempt uuid, p_question uuid, p_chosen int, p_marked boolean) returns timestamptz
language plpgsql security definer set search_path = public as $$
declare a public.attempts;
begin
  select * into a from public.attempts where id = p_attempt and student_id = auth.uid();
  if not found then raise exception 'Attempt not found'; end if;
  if a.status <> 'in_progress' then raise exception 'Exam already submitted'; end if;
  if now() > a.deadline_at + interval '3 seconds' then raise exception 'Time is up'; end if;
  if not (a.qorder ? p_question::text) then raise exception 'Question not in this exam'; end if;
  if p_chosen is not null and (p_chosen < 0 or p_chosen > 3) then raise exception 'Bad option'; end if;
  insert into public.answers(attempt_id, question_id, chosen, marked)
  values (p_attempt, p_question, p_chosen, coalesce(p_marked, false))
  on conflict (attempt_id, question_id) do update
    set chosen = excluded.chosen, marked = excluded.marked, updated_at = now();
  return now();
end $$;

-- student: submit (safe to call twice)
create function public.submit_attempt(p_attempt uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.attempts where id = p_attempt and student_id = auth.uid()) then
    raise exception 'Attempt not found'; end if;
  perform public._score_attempt(p_attempt);
end $$;

-- student: result + review (answers only appear once results are released)
create function public.get_result(p_attempt uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a public.attempts; e public.exams; rel boolean;
begin
  select * into a from public.attempts where id = p_attempt and student_id = auth.uid();
  if not found then raise exception 'Attempt not found'; end if;
  if a.status = 'in_progress' and a.deadline_at <= now() then
    perform public._score_attempt(a.id);
    select * into a from public.attempts where id = p_attempt;
  end if;
  if a.status <> 'submitted' then raise exception 'This attempt is not submitted yet'; end if;
  select * into e from public.exams where id = a.exam_id;
  rel := e.results_mode = 'instant' or e.ends_at is null or now() >= e.ends_at;
  if not rel then
    return jsonb_build_object('released', false, 'title', e.title, 'releases_at', e.ends_at);
  end if;
  return jsonb_build_object('released', true, 'title', e.title, 'exam_id', e.id,
    'score', a.score, 'correct', a.correct, 'wrong', a.wrong, 'skipped', a.skipped,
    'total_marks', (select count(*) from public.exam_questions where exam_id = e.id) * e.marks_per_q,
    'secs', extract(epoch from (a.submitted_at - a.started_at))::int,
    'review', (select coalesce(jsonb_agg(jsonb_build_object(
        'id', q.id, 'text', q.text, 'options', q.options, 'correct', q.correct_index,
        'explanation', q.explanation, 'image_url', q.image_url,
        'chosen', an.chosen, 'marked', coalesce(an.marked, false)) order by o.ord), '[]')
      from jsonb_array_elements_text(a.qorder) with ordinality o(qid, ord)
      join public.questions q on q.id = o.qid::uuid
      left join public.answers an on an.attempt_id = a.id and an.question_id = q.id));
end $$;

-- admin: results of all attempts
create function public.admin_results() returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  perform public._finalize(null);
  return coalesce((select jsonb_agg(jsonb_build_object(
    'attempt_id', a.id, 'exam_id', a.exam_id, 'exam', e.title, 'student', p.display_name,
    'score', a.score, 'correct', a.correct, 'wrong', a.wrong, 'skipped', a.skipped,
    'submitted_at', a.submitted_at, 'secs', extract(epoch from (a.submitted_at - a.started_at))::int
  ) order by a.submitted_at desc)
  from public.attempts a join public.exams e on e.id = a.exam_id join public.profiles p on p.id = a.student_id
  where a.status = 'submitted'), '[]'::jsonb);
end $$;

-- admin: students list
create function public.admin_students() returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object(
    'id', p.id, 'name', p.display_name, 'email', u.email, 'role', p.role, 'blocked', p.blocked,
    'joined', p.created_at,
    'attempts', (select count(*) from public.attempts a where a.student_id = p.id and a.status = 'submitted')
  ) order by p.created_at desc)
  from public.profiles p join auth.users u on u.id = p.id), '[]'::jsonb);
end $$;

create function public.set_blocked(p_uid uuid, p_blocked boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  update public.profiles set blocked = p_blocked where id = p_uid and role <> 'admin';
end $$;

-- ---------- lock down who can call what ----------
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.student_exams() to authenticated;
grant execute on function public.start_attempt(uuid) to authenticated;
grant execute on function public.get_attempt(uuid) to authenticated;
grant execute on function public.save_answer(uuid, uuid, int, boolean) to authenticated;
grant execute on function public.submit_attempt(uuid) to authenticated;
grant execute on function public.get_result(uuid) to authenticated;
grant execute on function public.admin_results() to authenticated;
grant execute on function public.admin_students() to authenticated;
grant execute on function public.set_blocked(uuid, boolean) to authenticated;

-- ---------- image storage for questions ----------
insert into storage.buckets (id, name, public) values ('question-images', 'question-images', true)
  on conflict (id) do nothing;
create policy qimg_admin_write on storage.objects for insert to authenticated
  with check (bucket_id = 'question-images' and public.is_admin());
create policy qimg_admin_delete on storage.objects for delete to authenticated
  using (bucket_id = 'question-images' and public.is_admin());
